# Data Manifest

This git archive stores code and lightweight metadata only. Large data and embeddings are deliberately excluded.

## Required Local Inputs

From repo root:

```text
D_with_image_paths.csv -> ../data/master_smri/D_with_image_paths_full.csv
data/embeddings_128 -> ../../data/embeddings_128
```

The symlinks above are local convenience links and are ignored by git.

## Canonical Data Locations

```text
/dcs07/zwang/data/adni_d/data/master_smri/D_with_image_paths_full.csv
/dcs07/zwang/data/adni_d/data/master_smri/matched_TRAIN_with_batch.csv
/dcs07/zwang/data/adni_d/data/master_smri/matched_TEST_with_batch.csv
/dcs07/zwang/data/adni_d/data/embeddings_128/
/dcs07/zwang/data/adni_d/data/embeddings/
```

## Generated Wang Inputs

`wang_input_k*.csv` files are reproducible from:

```bash
python scripts/build_wang_input.py --d_path D_with_image_paths.csv --embed_dir data/embeddings_128 --K 5 --out wang_input_k15.csv
```

They should not be committed.


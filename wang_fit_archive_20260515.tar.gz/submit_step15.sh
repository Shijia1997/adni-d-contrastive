#!/bin/bash
#SBATCH -J wang_k15_cons
#SBATCH -p shared
#SBATCH -t 24:00:00
#SBATCH -c 12
#SBATCH --mem=48G
#SBATCH -o logs/step15_%j.out
#SBATCH -e logs/step15_%j.err

set -eo pipefail

cd "$SLURM_SUBMIT_DIR"
mkdir -p logs

module load R/4.3
export R_LIBS_USER=/dcs07/zwang/data/adni_d/wang_fit/R_libs
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export OPENBLAS_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export MKL_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export VECLIB_MAXIMUM_THREADS="${SLURM_CPUS_PER_TASK}"
export NUMEXPR_NUM_THREADS="${SLURM_CPUS_PER_TASK}"

echo "=== Conservative k=15 fit (10 scalar + top 5 image PC) ==="
echo "Started: $(date)"
echo "Working dir: $(pwd)"
echo "Rscript: $(which Rscript)"
echo "R_LIBS_USER: ${R_LIBS_USER}"
echo "Threads: ${SLURM_CPUS_PER_TASK}"
echo "p_weight: 10"
echo "image gamma1_fixed init: 1.5"
echo ""

Rscript R/converge_k20.R \
  wang_input_k15.csv \
  adni_k15_conservative/ \
  ADNI_k15/ \
  15 \
  10

echo ""
echo "Done: $(date)"

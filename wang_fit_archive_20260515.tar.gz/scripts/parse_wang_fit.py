#!/usr/bin/env python
import argparse
import glob
from pathlib import Path

import numpy as np
import pandas as pd


NAMES_K10 = [
    "MMSCORE",
    "logmem",
    "DSST",
    "biec.thik",
    "bihippo",
    "biec.vol",
    "MTL1",
    "TAU",
    "PTAU",
    "ABETA",
]
NAMES_K20 = NAMES_K10 + [f"IMG_PC{i}" for i in range(1, 11)]

ZHEYU_INIT_G3 = np.array([2.533621, 2.242419, 2.375277, 1.609930, 2.040579,
                          1.711883, 1.809339, 1.000390, 0.533025, 0.254043])


def latest_theta(result_dir):
    files = sorted(glob.glob(str(Path(result_dir) / "*theta*.csv")))
    if not files:
        raise SystemExit(f"STOP: no theta files found in {result_dir}")
    return files[-1], pd.read_csv(files[-1])


def parse_k10(theta):
    names = NAMES_K10
    final_g3 = theta.iloc[:, 7].astype(float).values
    diff = final_g3 - ZHEYU_INIT_G3
    print("\n=== k=10 gamma3 comparison ===")
    print(f"{'Biomarker':<12} {'Zheyu init':>11} {'fit':>10} {'diff':>+9}")
    for name, init, fit, d in zip(names, ZHEYU_INIT_G3, final_g3, diff):
        print(f"{name:<12} {init:>11.3f} {fit:>10.3f} {d:>+9.3f}")

    ordering = np.argsort(final_g3)
    print("\nOrdering earliest -> latest:")
    print([names[i] for i in ordering])
    print("\nPASS checks:")
    print(f"  no NaN/Inf theta: {np.isfinite(theta.select_dtypes(include=[np.number]).values).all()}")
    print(f"  max |gamma3 diff| < 0.3: {np.nanmax(np.abs(diff)):.3f}")
    print(f"  earliest is ABETA: {names[ordering[0]] == 'ABETA'} ({names[ordering[0]]})")
    print(f"  latest is MMSCORE: {names[ordering[-1]] == 'MMSCORE'} ({names[ordering[-1]]})")


def parse_k20(theta):
    names = NAMES_K20
    print("\n=== k=20 final theta ===")
    print(f"{'Biomarker':<12} {'g1':>8} {'g2':>8} {'g3':>+8} {'sigma':>8}")
    for i, name in enumerate(names):
        g1, g2, g3, sigma = theta.iloc[i, 5:9].astype(float)
        print(f"{name:<12} {g1:>8.3f} {g2:>8.3f} {g3:>+8.3f} {sigma:>8.3f}")

    ordering = sorted(range(len(names)), key=lambda i: float(theta.iloc[i, 7]))
    print("\nOrdering earliest -> latest:")
    for rank, i in enumerate(ordering, start=1):
        print(f"  {rank:2d}. {names[i]:<12} g3={float(theta.iloc[i, 7]):+.3f}")

    img_g2 = theta.iloc[10:20, 6].astype(float).values
    print("\nImage PC gamma2 health:")
    print(f"  flat g2 < 1: {(img_g2 < 1).sum()}/10")
    print(f"  saturated g2 > 9: {(img_g2 > 9).sum()}/10")
    print(f"  healthy 2 <= g2 <= 8: {((img_g2 >= 2) & (img_g2 <= 8)).sum()}/10")

    scalar_g3 = theta.iloc[:10, 7].astype(float).values
    print("\nScalar gamma3 drift vs Zheyu init:")
    print(f"  max |drift|: {np.nanmax(np.abs(scalar_g3 - ZHEYU_INIT_G3)):.3f}")
    print(f"  mean |drift|: {np.nanmean(np.abs(scalar_g3 - ZHEYU_INIT_G3)):.3f}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--result_dir", required=True)
    parser.add_argument("--k", type=int, choices=[10, 20], required=True)
    args = parser.parse_args()

    theta_path, theta = latest_theta(args.result_dir)
    print(f"Latest theta: {theta_path}")
    print(f"Theta shape: {theta.shape}")
    print(f"Columns: {theta.columns.tolist()}")
    numeric = theta.select_dtypes(include=[np.number]).values
    print(f"Finite numeric entries: {np.isfinite(numeric).all()}")
    if args.k == 10:
        parse_k10(theta)
    else:
        parse_k20(theta)


if __name__ == "__main__":
    main()

"""
build_wang_input.py
====================
将 D_with_image_paths.csv + image PC (K=10 默认) 转成 Wang fit-ready CSV.

Output layout:
  cols 1-20: biomarker (10 scalar + 10 image PC z-scored)
  cols 21-24: covariates (age, apoe, sex, edu)
  cols 25+: metadata (RID, EXAMDATE, dx, d_mod3, etc.)

支持 k=10 mode (verify, 不加 image PC)
     k=20 mode (10 scalar + 10 image PC)
"""

import argparse
import numpy as np
import pandas as pd
from pathlib import Path


# Wang fit 用的 10 scalar biomarker, 这个顺序必须跟 theta.csv 一致
SCALAR_COLS = [
    "MMSCORE",     # row 1
    "logmem",      # row 2
    "DSST",        # row 3
    "biec.thik",   # row 4
    "bihippo",     # row 5
    "biec.vol",    # row 6
    "MTL1",        # row 7
    "TAU",         # row 8
    "PTAU",        # row 9
    "ABETA",       # row 10
]

# Wang fit 用的 covariate (顺序: age, apoe, sex, edu)
COVARIATE_COLS = ["age", "apoe", "PTGENDER", "education"]

# Metadata kept for downstream analysis (not used in fit but trailed on)
METADATA_COLS = [
    "RID", "PTID", "EXAMDATE.x", "PHASE.x", "dx",
    "d_mod3", "d_mod2", "ageori", "diagyear",
    "sMRI_path", "JSM_path", "Image_Data_ID", "scan_date",
    "image_CDGLOBAL", "gap_days_DI",
    "META_TEMPORAL_SUVR", "CENTILOIDS", "SUMMARY_SUVR",
]


def load_image_pcs(K, embed_dir):
    """Load PCA K=10 image features and return iid_to_pc dict (train + test)."""
    Z_train = np.load(f"{embed_dir}/swin_combat_pca_z_train.npy")
    Z_test  = np.load(f"{embed_dir}/swin_combat_pca_z_test.npy")
    train_ids = np.load(f"{embed_dir}/swin_combat_pca_z_train_ids.npy", allow_pickle=True)
    test_ids  = np.load(f"{embed_dir}/swin_combat_pca_z_test_ids.npy", allow_pickle=True)
    
    iid_to_pc = {}
    for i, iid in enumerate(train_ids):
        iid_to_pc[iid] = Z_train[i, :K]
    for i, iid in enumerate(test_ids):
        iid_to_pc[iid] = Z_test[i, :K]
    
    print(f"Loaded image PC: {len(iid_to_pc)} unique images, K={K}")
    return iid_to_pc


def build_input(d_path, embed_dir, K, out_path):
    """Build Wang fit-ready CSV.
    
    K: number of image PCs to include. K=0 means scalar-only (verify mode).
    """
    print(f"\nLoading D_with_image_paths from {d_path}")
    df = pd.read_csv(d_path)
    print(f"  Shape: {df.shape}")
    print(f"  Unique RIDs: {df['RID'].nunique()}")
    
    # Verify required columns exist
    missing_scalar = [c for c in SCALAR_COLS if c not in df.columns]
    missing_cov = [c for c in COVARIATE_COLS if c not in df.columns]
    if missing_scalar:
        raise ValueError(f"Missing scalar columns: {missing_scalar}")
    if missing_cov:
        raise ValueError(f"Missing covariate columns: {missing_cov}")
    
    print(f"\nScalar coverage:")
    for c in SCALAR_COLS:
        n_obs = df[c].notna().sum()
        print(f"  {c:15s}: {n_obs:5d} obs ({df[c].isna().sum()} NA)")
    
    # Optional: Load image PCs
    pc_cols = []
    if K > 0:
        iid_to_pc = load_image_pcs(K, embed_dir)
        
        pc_array = np.full((len(df), K), np.nan)
        n_matched = 0
        for i, iid in enumerate(df["Image_Data_ID"]):
            if pd.notna(iid) and iid in iid_to_pc:
                pc_array[i] = iid_to_pc[iid]
                n_matched += 1
        
        for k in range(K):
            col = f"image_pc_{k+1}"
            df[col] = pc_array[:, k]
            pc_cols.append(col)
        
        print(f"\nImage PC matched: {n_matched}/{len(df)} rows ({n_matched/len(df)*100:.1f}%)")
        print(f"Visits without image: PC values will be NA (Wang fit handles NA per-visit)")
    
    # Build output column order:
    #   biomarker (scalar + image PC), then covariate, then metadata
    biomarker_cols = SCALAR_COLS + pc_cols
    output_cols = biomarker_cols + COVARIATE_COLS
    
    # Add metadata if present
    for c in METADATA_COLS:
        if c in df.columns:
            output_cols.append(c)
    
    out_df = df[output_cols].copy()
    
    # Critical: Wang fit drops rows where ALL biomarker NA + Wang fit 要求 covariate non-NA
    n_before = len(out_df)
    out_df = out_df.dropna(subset=COVARIATE_COLS, how="any")
    n_after = len(out_df)
    print(f"\nDrop rows with NA covariate: {n_before} → {n_after}")
    
    # Also drop rows with ALL biomarker NA (no info to fit)
    all_na_mask = out_df[biomarker_cols].isna().all(axis=1)
    out_df = out_df[~all_na_mask]
    print(f"Drop rows with all biomarker NA: → {len(out_df)}")
    
    # Save
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    out_df.to_csv(out_path, index=False)
    print(f"\n✓ Saved {len(out_df)} rows × {out_df.shape[1]} cols → {out_path}")
    print(f"  Column 1-{len(biomarker_cols)}: biomarker ({len(SCALAR_COLS)} scalar + {len(pc_cols)} image PC)")
    print(f"  Column {len(biomarker_cols)+1}-{len(biomarker_cols)+len(COVARIATE_COLS)}: covariate")
    print(f"  Column {len(biomarker_cols)+len(COVARIATE_COLS)+1}+: metadata")
    
    # Print sample
    print(f"\nFirst 3 rows (biomarker + covariate):")
    print(out_df[biomarker_cols + COVARIATE_COLS].head(3).to_string())
    
    return out_df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--d_path", default="D_with_image_paths.csv",
                        help="Path to merged D + image dataset")
    parser.add_argument("--embed_dir", default="data/embeddings_128",
                        help="Path to 128 PCA embeddings")
    parser.add_argument("--K", type=int, default=10,
                        help="Number of image PCs (0 for verify mode)")
    parser.add_argument("--out", default="wang_input_k20.csv",
                        help="Output CSV path")
    args = parser.parse_args()
    
    build_input(args.d_path, args.embed_dir, args.K, args.out)


if __name__ == "__main__":
    main()

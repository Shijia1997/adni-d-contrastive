"""
run_r_fit.py
=============
Robust Python wrapper to run R fit scripts via subprocess.

Uses subprocess.run() rather than rpy2:
  - More robust (rpy2 has compilation issues)
  - Simpler (no R-Python state sharing needed)
  - Easier to debug (R errors visible in stdout/stderr)
  - All exchange via CSV files
"""

import argparse
import subprocess
import sys
import time
from pathlib import Path


def run_rscript(r_script, args=(), cwd=None, timeout=None):
    """Run Rscript with args. Streams stdout in real-time."""
    cmd = ["Rscript", r_script] + list(args)
    print(f"\n{'='*70}")
    print(f"CMD: {' '.join(cmd)}")
    print(f"CWD: {cwd or Path.cwd()}")
    print(f"{'='*70}")
    
    start = time.time()
    
    # Stream output line-by-line
    process = subprocess.Popen(
        cmd,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    
    lines = []
    try:
        for line in iter(process.stdout.readline, ""):
            if not line:
                break
            print(line, end="", flush=True)
            lines.append(line)
            if timeout and (time.time() - start) > timeout:
                process.kill()
                raise TimeoutError(f"R script exceeded {timeout}s")
    except KeyboardInterrupt:
        print("\n!! Interrupted by user, killing R process")
        process.kill()
        raise
    
    process.wait()
    elapsed = time.time() - start
    
    print(f"\n{'='*70}")
    print(f"DONE in {elapsed:.1f}s (return code: {process.returncode})")
    print(f"{'='*70}")
    
    if process.returncode != 0:
        print(f"!! R script failed with return code {process.returncode}")
        sys.exit(process.returncode)
    
    return "".join(lines), elapsed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--r_script", required=True, help="Path to R script to run")
    parser.add_argument("--args", nargs="*", default=[], help="Args to pass to R script")
    parser.add_argument("--cwd", default=None, help="Working directory")
    parser.add_argument("--timeout", type=int, default=None, help="Timeout in seconds")
    args = parser.parse_args()
    
    output, elapsed = run_rscript(args.r_script, args.args, args.cwd, args.timeout)
    
    print(f"\nFinal elapsed: {elapsed:.1f}s")


if __name__ == "__main__":
    main()

"""
run_bootstrap.py
=================
Bootstrap framework for Wang model fit. Resamples RID with replacement,
runs converge_k20.R, saves params.

Usage:
  Single iter:        python run_bootstrap.py --iter 1 --seed 42
  SLURM array:        sbatch -a 1-100 bootstrap.sh
                        (where bootstrap.sh calls this with --iter $SLURM_ARRAY_TASK_ID)

Output for each iter:
  bootstrap_output/iter_NNN/
    theta_final.csv
    phi_final.csv
    cor_final.csv
    log.txt
"""

import argparse
import numpy as np
import pandas as pd
import subprocess
import sys
import time
from pathlib import Path
import json


def resample_by_rid(input_csv, seed):
    """Resample subjects (RID) with replacement, return new dataframe."""
    df = pd.read_csv(input_csv)
    np.random.seed(seed)
    
    unique_rids = df["RID"].unique()
    n_rids = len(unique_rids)
    
    # Resample RID with replacement
    sampled_rids = np.random.choice(unique_rids, size=n_rids, replace=True)
    
    # Build new df with potentially repeated subjects
    # For duplicate RIDs, we need unique row identity so fit treats them as separate subjects
    new_rows = []
    for new_idx, rid in enumerate(sampled_rids):
        rid_rows = df[df["RID"] == rid].copy()
        # Reassign new RID for duplicates so fit treats as independent subjects
        rid_rows["bootstrap_orig_RID"] = rid
        rid_rows["RID"] = f"BS{new_idx:04d}"
        new_rows.append(rid_rows)
    
    new_df = pd.concat(new_rows, ignore_index=True)
    return new_df


def run_bootstrap_iter(iter_idx, seed, base_input, R_script, base_init_dir,
                       working_dir, output_root):
    """Run one bootstrap iteration."""
    print(f"\n{'='*70}")
    print(f"BOOTSTRAP ITER {iter_idx} (seed={seed})")
    print(f"{'='*70}")
    
    iter_out_dir = Path(output_root) / f"iter_{iter_idx:04d}"
    iter_out_dir.mkdir(parents=True, exist_ok=True)
    
    # 1. Resample
    bs_df = resample_by_rid(base_input, seed)
    bs_csv = iter_out_dir / "bootstrap_input.csv"
    bs_df.to_csv(bs_csv, index=False)
    print(f"  Resampled: {len(bs_df)} rows from {bs_df['RID'].nunique()} pseudo-subjects")
    print(f"  Saved to:  {bs_csv}")
    
    # 2. Run R fit (with main fit init values, faster convergence)
    fit_output = iter_out_dir / "fit_output"
    fit_output.mkdir(exist_ok=True)
    
    start = time.time()
    cmd = ["Rscript", R_script,
           str(bs_csv.absolute()),
           str(fit_output.absolute()) + "/",
           str(Path(base_init_dir).absolute()) + "/"]
    
    print(f"  Running R fit...")
    print(f"  CMD: {' '.join(cmd)}")
    
    log_path = iter_out_dir / "log.txt"
    with open(log_path, "w") as logf:
        result = subprocess.run(
            cmd, cwd=working_dir,
            stdout=logf, stderr=subprocess.STDOUT,
            timeout=14400  # 4 hour per iter
        )
    
    elapsed = time.time() - start
    print(f"  Fit completed in {elapsed:.1f}s, return code: {result.returncode}")
    
    if result.returncode != 0:
        print(f"  !! Fit failed for iter {iter_idx}")
        return False
    
    # 3. Parse final theta/phi/cor from R log or output
    # (Wang's nlme_gqnr writes to output_path/result/*.csv per iteration)
    # We grab the LAST iteration's saved theta/phi/cor.
    result_dir = fit_output / "result"
    if not result_dir.exists():
        print(f"  !! No result dir found")
        return False
    
    # Find latest iter files (named iter_NN_theta.csv etc.)
    theta_files = sorted(result_dir.glob("*theta*.csv"))
    if not theta_files:
        print(f"  !! No theta files in result dir")
        return False
    
    final_theta = theta_files[-1]
    print(f"  Final theta: {final_theta.name}")
    
    # Copy final to summary
    import shutil
    shutil.copy(final_theta, iter_out_dir / "theta_final.csv")
    
    # Save metadata
    meta = {
        "iter": iter_idx,
        "seed": seed,
        "elapsed_sec": elapsed,
        "n_rows": len(bs_df),
        "n_unique_orig_rid": int(bs_df["bootstrap_orig_RID"].nunique()),
        "return_code": result.returncode,
        "final_theta_file": str(final_theta.name),
    }
    with open(iter_out_dir / "meta.json", "w") as f:
        json.dump(meta, f, indent=2)
    
    return True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--iter", type=int, required=True, help="Iteration index 1-100")
    parser.add_argument("--seed", type=int, default=None, help="Random seed (default: iter)")
    parser.add_argument("--base_input", default="wang_input_k20.csv",
                        help="Base input CSV to resample from")
    parser.add_argument("--r_script", default="converge_k20.R",
                        help="R fit script")
    parser.add_argument("--init_dir", default="ADNI",
                        help="Init values dir (theta/phi/cor.csv)")
    parser.add_argument("--working_dir", default=".", help="R working dir")
    parser.add_argument("--output_root", default="bootstrap_output",
                        help="Bootstrap output root dir")
    args = parser.parse_args()
    
    seed = args.seed if args.seed is not None else args.iter
    success = run_bootstrap_iter(
        args.iter, seed,
        args.base_input, args.r_script, args.init_dir,
        args.working_dir, args.output_root,
    )
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()

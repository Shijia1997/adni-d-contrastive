"""
verify_columns.py
==================
Quick sanity check: 
  1. D_with_image_paths.csv 含 build_wang_input.py expected columns
  2. Image_Data_ID format 跟 image PC npy IDs 一致
  3. Print 一些 sample matching

跑这个 在 build_wang_input.py 之前, 30 second 验证 全部对得上.
"""

import sys
import numpy as np
import pandas as pd


# Expected by build_wang_input.py
SCALAR_COLS = ["MMSCORE", "logmem", "DSST", "biec.thik", "bihippo",
               "biec.vol", "MTL1", "TAU", "PTAU", "ABETA"]
COVARIATE_COLS = ["age", "apoe", "PTGENDER", "education"]


def main():
    d_path = sys.argv[1] if len(sys.argv) > 1 else "D_with_image_paths.csv"
    embed_dir = sys.argv[2] if len(sys.argv) > 2 else "data/embeddings_128"
    
    print(f"="*70)
    print(f"VERIFY: column names + ID format alignment")
    print(f"="*70)
    
    # 1. Check D_with_image_paths.csv columns
    print(f"\n[1] Loading {d_path}")
    df = pd.read_csv(d_path, nrows=10)
    print(f"  Shape (preview): {df.shape}")
    print(f"  Columns ({len(df.columns)}):")
    for c in df.columns:
        print(f"    {c}")
    
    # Verify all required columns present
    missing_scalar = [c for c in SCALAR_COLS if c not in df.columns]
    missing_cov = [c for c in COVARIATE_COLS if c not in df.columns]
    missing_id = "Image_Data_ID" not in df.columns
    
    print(f"\n[2] Required column check:")
    print(f"  Scalar biomarker ({len(SCALAR_COLS)}):")
    for c in SCALAR_COLS:
        mark = "✓" if c in df.columns else "✗ MISSING"
        print(f"    {c:15s} {mark}")
    
    print(f"  Covariate ({len(COVARIATE_COLS)}):")
    for c in COVARIATE_COLS:
        mark = "✓" if c in df.columns else "✗ MISSING"
        print(f"    {c:15s} {mark}")
    
    print(f"  Image_Data_ID: {'✓' if not missing_id else '✗ MISSING'}")
    
    if missing_scalar or missing_cov or missing_id:
        print(f"\n!! FAIL: missing required columns")
        if missing_scalar:
            print(f"   Scalar missing: {missing_scalar}")
        if missing_cov:
            print(f"   Covariate missing: {missing_cov}")
        sys.exit(1)
    
    print(f"\n[3] Loading full data and checking Image_Data_ID values")
    df_full = pd.read_csv(d_path)
    print(f"  Full shape: {df_full.shape}")
    print(f"  Total rows: {len(df_full)}")
    print(f"  Rows with Image_Data_ID non-NA: {df_full['Image_Data_ID'].notna().sum()}")
    print(f"  Unique Image_Data_ID: {df_full['Image_Data_ID'].nunique()}")
    
    # Sample Image_Data_ID values
    sample_ids = df_full['Image_Data_ID'].dropna().unique()[:5]
    print(f"  Sample Image_Data_ID values: {sample_ids.tolist()}")
    
    # 4. Load image PC npy and check IDs match
    print(f"\n[4] Loading image PC npy from {embed_dir}")
    try:
        train_ids = np.load(f"{embed_dir}/swin_combat_pca_z_train_ids.npy", allow_pickle=True)
        test_ids = np.load(f"{embed_dir}/swin_combat_pca_z_test_ids.npy", allow_pickle=True)
        Z_train = np.load(f"{embed_dir}/swin_combat_pca_z_train.npy")
        print(f"  Train IDs: {len(train_ids)} unique")
        print(f"  Test IDs: {len(test_ids)} unique")
        print(f"  Z_train shape: {Z_train.shape}")
        print(f"  Sample train IDs: {train_ids[:5].tolist()}")
    except FileNotFoundError as e:
        print(f"  !! Missing npy file: {e}")
        sys.exit(1)
    
    # 5. ID format match check
    print(f"\n[5] ID format match check")
    pc_ids = set(train_ids.tolist()) | set(test_ids.tolist())
    csv_ids = set(df_full['Image_Data_ID'].dropna().unique().tolist())
    
    overlap = pc_ids & csv_ids
    only_pc = pc_ids - csv_ids
    only_csv = csv_ids - pc_ids
    
    print(f"  Total PC ids:  {len(pc_ids)}")
    print(f"  Total CSV ids: {len(csv_ids)}")
    print(f"  Overlap:       {len(overlap)} ← critical, should be close to len(pc_ids)")
    print(f"  Only in PC:    {len(only_pc)}")
    print(f"  Only in CSV:   {len(only_csv)}")
    
    if len(only_pc) > 0:
        print(f"  Sample 'only in PC': {list(only_pc)[:5]}")
    if len(only_csv) > 0:
        print(f"  Sample 'only in CSV': {list(only_csv)[:5]}")
    
    overlap_rate = len(overlap) / len(pc_ids) if len(pc_ids) > 0 else 0
    print(f"  Overlap rate: {overlap_rate*100:.1f}%")
    
    if overlap_rate < 0.9:
        print(f"\n!! WARNING: low overlap suggests ID format mismatch")
        print(f"   Check if D_with_image_paths.csv Image_Data_ID has prefix/suffix")
    
    # 6. Check Image PC array dimension
    print(f"\n[6] Image PC dimension check")
    print(f"  Z_train shape: {Z_train.shape}")
    print(f"  K=10 will take cols 0-9 (first 10 PCs)")
    print(f"  Used for: image_pc_1, image_pc_2, ..., image_pc_10")
    
    # 7. Predicted final dataset size
    print(f"\n[7] Predicted Wang fit dataset stats")
    n_with_covariate = df_full.dropna(subset=COVARIATE_COLS).shape[0]
    n_with_any_biomarker = df_full[SCALAR_COLS].notna().any(axis=1).sum()
    n_with_image = df_full['Image_Data_ID'].isin(pc_ids).sum()
    print(f"  Rows with all 4 covariates: {n_with_covariate}")
    print(f"  Rows with any of 10 biomarker: {n_with_any_biomarker}")
    print(f"  Rows with image (PC available): {n_with_image}")
    
    print(f"\n{'='*70}")
    print(f"VERIFY COMPLETE — All required mappings ✓")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()

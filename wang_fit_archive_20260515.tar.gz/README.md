# Wang Joint Model + Image PC — Operation Guide (Path B)

## Goal
Plug K=10 image PCs into Wang's joint AD progression model.
Total k=20 biomarker (10 scalar + 10 image PC), reuse Wang's R machinery.

## Files

```
wang_image_fit/
├── README.md                   (this file)
├── ADNI/                       (init values for k=20 fit)
│   ├── theta.csv               (20 rows: 10 Zheyu + 10 image PC default)
│   ├── phi.csv                 (same as Zheyu)
│   └── cor.csv                 (same as Zheyu, image PC assumed independent)
├── ADNI_k10/                   (init values for k=10 verify)
│   ├── theta.csv               (Zheyu's original 10 biomarker)
│   ├── phi.csv
│   └── cor.csv
├── R/
│   ├── converge_k10_verify.R   (k=10 reproduce, Step 1)
│   ├── converge_k20.R          (k=20 image fit, Step 2)
│   └── (need to add Zheyu's: ADLDA_funs.R, newton_iter.R, test0822.cpp)
├── scripts/
│   ├── build_wang_input.py     (data prep)
│   ├── run_r_fit.py            (Python subprocess wrapper)
│   └── run_bootstrap.py        (bootstrap framework)
└── prompts/
    ├── step1_verify.md         (Step 1 prompt for Claude Code)
    ├── step2_fit.md            (Step 2 prompt)
    └── step3_evaluate.md       (Step 3 prompt)
```

## Required Inputs (you provide)

1. `D_with_image_paths.csv` (你之前 build, 含 scaled biomarker + image path + d_mod3)
2. `data/embeddings_128/swin_combat_pca_z_*.npy` (image PC K=30, 我们用 K=10)
3. `data/master_smri/matched_TRAIN_with_batch.csv` (train/test split)
4. `R/ADLDA_funs.R`, `R/newton_iter.R`, `R/test0822.cpp` (Zheyu's machinery, copy in)

## Operation Sequence

### Step 1: Verify k=10 reproducibility (1 day)
- Follow `prompts/step1_verify.md`
- Goal: confirm R machinery + data format 跑通
- Reproduce Zheyu's 10 biomarker fit
- Expect: NR converges < 20 iter, γ_3 close to init

### Step 2: Main fit k=20 + bootstrap (3-5 day)
- Follow `prompts/step2_fit.md`
- Build wang_input_k20.csv (K=10 image PC added)
- Run main fit (~2-3 day CPU)
- Submit bootstrap 100 iter (~1-2 day parallel)

### Step 3: Evaluate (1-2 day)
- Follow `prompts/step3_evaluate.md`
- Generate trajectory figure
- Compute ordering table + bootstrap CI
- Compute individual D̂ per visit
- Compare vs Zheyu's d_mod3

## Key Risks

1. **R machinery compilation**: test0822.cpp 需要 Rcpp + working gcc. 
   If fails on JHPCE, request `bithelp@lists.jh.edu` to install Rcpp.

2. **NR fit divergence**: 20 biomarker more params, may not converge.
   Mitigation: K=10 image PC (not 30), good init from Zheyu's k=10.

3. **Image PC flat sigmoid (γ_2 ≈ 0)**: Some image PCs may fit flat.
   Expected: paper reports these as "not significant ordering".

4. **Bootstrap CPU**: 100 iter × ~2 hour/iter = 200 hour single-CPU.
   With 25 parallel SLURM jobs: ~8 hour wall time.

## Expected Outcome Scenarios

**A. Image PC strong (a few image PCs with γ_3 in [0, 1] = early cascade)**:
   Paper claim: "Foundation model imaging reveals early disease signal 
   alongside CSF biomarkers"
   → NeuroImage / A&D level paper

**B. Image PC mid-cascade (γ_3 mostly 1-2 = similar to MRI scalar)**:
   Paper claim: "Foundation model imaging captures same cascade 
   information as hand-crafted MRI biomarkers"
   → HBM / NeuroImage moderate paper

**C. Image PC mostly flat (γ_2 ≈ 0, no clear ordering)**:
   Paper claim: "Image embedding adds limited staging value beyond 
   scalar biomarkers in established cohort"
   → Negative finding, workshop paper

## Total Timeline

- Setup + data prep: 1 day
- Step 1 verify: 1 day
- Step 2 main fit: 2-3 day CPU wait
- Step 2 bootstrap: 1-2 day CPU parallel
- Step 3 evaluate: 1-2 day
- Paper writing: 3-4 weeks

Total: ~6-7 weeks from start to first paper draft.

================================================================
Step 1: VERIFY — Reproduce Zheyu's k=10 fit
================================================================

Background:
- 我们 plan plug image PCs 进 Wang joint model (Path B)
- 决定 K=10 image PC (k=20 total)
- 但 在 commit 6-7 周 fit 之前, 必须 verify R machinery 跑通
- 这个 Step 1 是 reproducibility check: 用 Zheyu 的 init + 现有 k=10 数据, 
  跑 converge.R, 看 fit 收敛 + ordering 是否 跟 Zheyu paper 一致

Files needed (all uploaded to your working dir):
  R/converge_k10_verify.R          (modified converge.R for verify)
  R/ADLDA_funs.R                    (Zheyu's, unchanged) 
  R/newton_iter.R                   (Zheyu's, unchanged)
  R/test0822.cpp                    (Zheyu's, unchanged)
  ADNI_k10/theta.csv                (Zheyu's 10-biomarker init)
  ADNI_k10/phi.csv
  ADNI_k10/cor.csv
  scripts/build_wang_input.py
  scripts/run_r_fit.py

================================================================
Pre-step: 装 R packages 如果没装
================================================================

R --no-save <<EOF
required <- c("statmod","MASS","boot","Rcpp","Matrix","mvtnorm","dplyr","common","logr")
for (p in required) {
    if (!require(p, character.only=TRUE, quietly=TRUE)) {
        install.packages(p, repos="https://cran.r-project.org")
    }
}
EOF

如果 install.packages 在 JHPCE cluster 上 fail, 用 module 系统:
  module load R
  module load r-statmod r-mass r-rcpp r-matrix r-mvtnorm r-dplyr
  (或者 R --vanilla 然后 .libPaths() 看 user library, install 到那)

================================================================
Step 1.1: Build wang_input_k10.csv (verify mode, K=0 image PC)
================================================================

cd to working dir (containing R/ ADNI_k10/ scripts/ etc.)

python scripts/build_wang_input.py \
  --d_path D_with_image_paths.csv \
  --K 0 \
  --out wang_input_k10.csv

期望 output:
  - 几千 rows × 30-ish cols  
  - First 10 cols: scaled biomarker (MMSCORE, logmem, DSST, ..., ABETA)
  - Cols 11-14: covariate (age, apoe, PTGENDER, education)
  - Cols 15+: metadata
  - Print scalar coverage per biomarker (DSST should be very sparse, others OK)

如果 build 失败:
  - 检查 D_with_image_paths.csv exists 在 working dir
  - 检查 列名 match (MMSCORE / logmem / DSST / biec.thik / bihippo / biec.vol / 
    MTL1 / TAU / PTAU / ABETA / age / apoe / PTGENDER / education)

STOP, paste:
  - Build output (shape, coverage, file head)

================================================================
Step 1.2: Run Wang fit (k=10 verify)
================================================================

# 先 cp 必需 R files 到 working dir
cp R/*.R R/*.cpp .

# 跑 fit
python scripts/run_r_fit.py \
  --r_script R/converge_k10_verify.R \
  --args wang_input_k10.csv adni_k10_verify/ ADNI_k10/

期望 behavior:
  - 因为 init = Zheyu's converged values, NR 应该 几 iter 就 stable
  - 单 iter 5-15 min on standard CPU
  - Maxit = 100 但应该 < 20 iter converge
  - 总时间 1-3 hour, 但 极可能 < 1 hour

监控:
  - 实时 stream stdout 看 likelihood 变化
  - 看 'theta0:' 和 final theta 是否 close (init 跟 estimated diff < 0.05 each)
  - 如果 likelihood NaN/Inf, STOP, paste error

如果 R fit 失败 (compile error, missing fn 等):
  Common issues:
  - test0822.cpp 编译 fail → 检查 Rcpp version, gcc available
  - logr / common package missing → install
  - "could not find function ..." → check ADLDA_funs.R source 跟 R script same dir
  
  Paste full error message, STOP.

================================================================
Step 1.3: Parse + verify output
================================================================

Read adni_k10_verify/result/*_theta.csv (final iter):
  - 10 rows × 9 cols (intercept, age, apoe, gender, edu, γ_1, γ_2, γ_3, σ)
  - γ_3 column (col 8): 跟 Zheyu init 应该 close
  
读 final γ_3 print 出来:
  Row 1 MMSCORE:    init γ_3 = 2.534, fit γ_3 = ?
  Row 2 logmem:     init γ_3 = 2.242, fit γ_3 = ?
  Row 3 DSST:       init γ_3 = 2.375, fit γ_3 = ?
  Row 4 biec.thik:  init γ_3 = 1.610, fit γ_3 = ?
  Row 5 bihippo:    init γ_3 = 2.041, fit γ_3 = ?
  Row 6 biec.vol:   init γ_3 = 1.712, fit γ_3 = ?
  Row 7 MTL1:       init γ_3 = 1.809, fit γ_3 = ?
  Row 8 TAU:        init γ_3 = 1.000, fit γ_3 = ?
  Row 9 PTAU:       init γ_3 = 0.533, fit γ_3 = ?
  Row 10 ABETA:     init γ_3 = 0.254, fit γ_3 = ?

Verify success criteria:
  ✓ All 10 fits converge (no NaN/Inf)
  ✓ Final γ_3 close to init (max diff < 0.3)
  ✓ Ordering preserved: ABETA < PTAU < TAU < MRI < cognitive
  ✓ Log likelihood final value finite + reasonable

================================================================
STOP. Paste:
================================================================
  1. Build output (Step 1.1)
  2. Fit log output (Step 1.2) — key sections:
     - "theta0:" initial value print
     - Iteration progress (likelihood 每 iter)
     - Final theta matrix
     - "=== Verify fit complete ===" message
  3. Final γ_3 comparison table (init vs fit)
  4. Number of iterations to converge
  5. Total wall time
  6. Any error / warning messages

DON'T proceed to Step 2 (k=20 image fit) until Step 1 verified passing.
================================================================

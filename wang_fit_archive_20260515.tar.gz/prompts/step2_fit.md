================================================================
Step 2: FIT — k=20 (10 scalar + 10 image PC) main fit + bootstrap
================================================================

Background:
- Step 1 已 verify R machinery 跑通
- 现在 add 10 image PC into joint model, k=20
- Main fit ~2-3 day CPU wait, bootstrap 100 iter parallel ~ 1-2 day

Prerequisites:
  ✓ Step 1 完成, k=10 reproducibility 通过
  ✓ Image PC files: data/embeddings_128/swin_combat_pca_z_train.npy etc.
  ✓ ADNI/theta.csv (20 行, 已 ready, 10 + 10 default)
  ✓ ADNI/phi.csv, cor.csv (跟 k=10 一致)

================================================================
Step 2.1: Build wang_input_k20.csv (K=10 image PC)
================================================================

python scripts/build_wang_input.py \
  --d_path D_with_image_paths.csv \
  --embed_dir data/embeddings_128 \
  --K 10 \
  --out wang_input_k20.csv

期望 output:
  - Same rows count as k=10 input
  - 多 10 columns (image_pc_1 to image_pc_10)
  - 大约 60-70% rows 有 image PC (剩余 NA, fit handles per-visit missingness)
  - Print image PC matched stats

STOP, paste:
  - Shape
  - Image PC matched count
  - First 3 rows of biomarker + image PC + covariate

================================================================
Step 2.2: Main Fit (k=20)
================================================================

# Copy R machinery + ADNI init dir to working dir
cp R/*.R R/*.cpp .
# ADNI/ dir 已经在 working dir (含 theta.csv 20 行, phi.csv, cor.csv)

# 跑 main fit
nohup python scripts/run_r_fit.py \
  --r_script R/converge_k20.R \
  --args wang_input_k20.csv adni_k20_main/ ADNI/ \
  > main_fit.log 2>&1 &

# 因 main fit 长 (2-3 days), 用 nohup background。
# 监控:
tail -f main_fit.log

监控关键 indicator:
  - "theta0:" 显示 20 行 init (前 10 是 Zheyu, 后 10 是 default zeros)
  - 每 iter likelihood 变化
  - 早期 几 iter likelihood 变化大 (image PC 跟 D 关系初始 fit)
  - 后期 (iter 30+) likelihood 应该 stable
  - 注意 NaN / Inf — STOP immediately if seen

预期:
  - 单 iter 30-60 min (20 biomarker, 大 Hessian)
  - 收敛 30-80 iter
  - Total: 24-48 hour wall time (single CPU)
  - 不一定 happy converge (NR fail rate ~ 20%)

如果 NR fail:
  - Likelihood Inf / NaN: STOP, check input data 有 outlier image PC value
  - "matrix singular": image PC + scalar correlation 太强, image PC 应该 standardized
  - "maximum iterations exceeded": 增加 maxit 到 800 retry

STOP, paste:
  - Time fit started
  - 前 10 iter likelihood values
  - 当前 iter (let me know periodically if not done)
  - 如果完成: final theta + log likelihood

================================================================
Step 2.3: Sanity check main fit output
================================================================

(After main fit completes)

# Read final theta
import pandas as pd
import numpy as np
import os

result_dir = "adni_k20_main/result"
theta_files = sorted([f for f in os.listdir(result_dir) if "theta" in f])
final_theta_path = os.path.join(result_dir, theta_files[-1])

theta_final = pd.read_csv(final_theta_path)
print(f"Final theta shape: {theta_final.shape}")
print(f"Final theta (cols 6-9: γ_1, γ_2, γ_3, σ):")
biomarker_names = ['MMSCORE','logmem','DSST','biec.thik','bihippo','biec.vol',
                   'MTL1','TAU','PTAU','ABETA',
                   'IMG_PC1','IMG_PC2','IMG_PC3','IMG_PC4','IMG_PC5',
                   'IMG_PC6','IMG_PC7','IMG_PC8','IMG_PC9','IMG_PC10']
for i, name in enumerate(biomarker_names):
    row = theta_final.iloc[i]
    g1 = row.iloc[5]
    g2 = row.iloc[6]
    g3 = row.iloc[7]
    sigma = row.iloc[8]
    print(f"  {name:12s}: γ_1={g1:.2f}, γ_2={g2:.3f}, γ_3={g3:+.3f}, σ={sigma:.3f}")

# Ranking
ordering_by_g3 = sorted(enumerate(biomarker_names), key=lambda x: theta_final.iloc[x[0], 7])
print(f"\n=== Ordering by γ_3 (earliest → latest) ===")
for rank, (idx, name) in enumerate(ordering_by_g3):
    g3 = theta_final.iloc[idx, 7]
    print(f"  Rank {rank+1:2d}: {name:12s} γ_3 = {g3:+.3f}")

# Image PC γ_2 saturation check
img_g2 = theta_final.iloc[10:20, 6].values
print(f"\nImage PC γ_2 (rate) stats: mean={img_g2.mean():.2f}, max={img_g2.max():.2f}")
print(f"  γ_2 < 1 (flat sigmoid): {(img_g2 < 1).sum()}/10")
print(f"  γ_2 > 9 (saturated): {(img_g2 > 9).sum()}/10")

期望 output 判断:
  ✓ Scalar biomarker γ_3 接近 Zheyu's k=10 fit  (验证 image PCs 没破坏 scalar fit)
  ✓ Image PC γ_3 跨 cascade 分布:
    - 几个 image PC γ_3 < 1 (early) — 跟 CSF / 早期 MRI 同位
    - 几个 image PC γ_3 1-2 (mid) — 跟 MRI 同位
    - 几个 image PC γ_3 > 2 (late) — 跟 cognitive 同位
  ⚠ 部分 image PC γ_2 < 1 (平 sigmoid) — expected, 报告 'not significant ordering'
  ⚠ 部分 image PC σ > 1.5 (信号弱) — expected

STOP, paste 上面 output.

================================================================
Step 2.4: Bootstrap (100 iter, SLURM parallel)
================================================================

(Only proceed if main fit reasonable)

# 准备 SLURM array job
cat > bootstrap.sh <<EOF
#!/bin/bash
#SBATCH -J wang_bootstrap
#SBATCH -t 8:00:00
#SBATCH -p shared
#SBATCH -c 1
#SBATCH --mem=8G
#SBATCH -o bootstrap_logs/slurm_%A_%a.out

cd \$SLURM_SUBMIT_DIR
mkdir -p bootstrap_logs

python scripts/run_bootstrap.py \\
  --iter \$SLURM_ARRAY_TASK_ID \\
  --seed \$SLURM_ARRAY_TASK_ID \\
  --base_input wang_input_k20.csv \\
  --r_script R/converge_k20.R \\
  --init_dir ADNI \\
  --output_root bootstrap_output
EOF

# Submit 100 iter (concurrent 25, conservative for cluster)
sbatch -a 1-100%25 bootstrap.sh

# 监控:
squeue -u \$USER
ls bootstrap_output/ | wc -l    # 看 iter 完成数

# 等所有完成 (1-2 day):
while squeue -u \$USER 2>&1 | grep -q wang_bootstrap; do
    sleep 600
    completed=\$(ls -d bootstrap_output/iter_* 2>/dev/null | wc -l)
    echo "Completed iters: \$completed / 100"
done

STOP after submit. Paste:
  - sbatch output (job ID)
  - 第一 5 个 iter complete 的 elapsed time
  - 任何 failed iter (return code != 0)

================================================================
End of Step 2. Wait for Step 3 evaluate.
================================================================

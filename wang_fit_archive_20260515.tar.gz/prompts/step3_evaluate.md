================================================================
Step 3: EVALUATE — Trajectory, ordering, individual D, bootstrap CI
================================================================

Background:
- Step 2 main fit (k=20) + 100 bootstrap iter 完成
- 这一步: build paper figure + table + Wang-style ordering inference

Prerequisites:
  ✓ adni_k20_main/result/<lastfile>_theta.csv (main fit final)
  ✓ adni_k20_main/result/<lastfile>_phi.csv  
  ✓ adni_k20_main/result/<lastfile>_cor.csv
  ✓ bootstrap_output/iter_NNNN/theta_final.csv × 100

================================================================
Step 3.1: Main fit output — trajectory plot
================================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load main fit
main_theta = pd.read_csv("adni_k20_main/result/<final_theta_file>")
biomarker_names = ['MMSCORE','logmem','DSST','biec.thik','bihippo','biec.vol',
                   'MTL1','TAU','PTAU','ABETA',
                   'IMG_PC1','IMG_PC2','IMG_PC3','IMG_PC4','IMG_PC5',
                   'IMG_PC6','IMG_PC7','IMG_PC8','IMG_PC9','IMG_PC10']

# γ_1, γ_2, γ_3 columns are 5, 6, 7 (0-indexed) in theta matrix
gamma1 = main_theta.iloc[:, 5].values
gamma2 = main_theta.iloc[:, 6].values
gamma3 = main_theta.iloc[:, 7].values

def sigmoid_curve(d, g1, g2, g3):
    """Symmetric sigmoid from paper Eq 2."""
    return g1 / (1 + np.exp(-g2 * (d - g3)))

# Plot all 20 trajectories
d_range = np.linspace(-3, 4, 200)
fig, ax = plt.subplots(figsize=(10, 6))
colors_scalar = plt.cm.viridis(np.linspace(0, 0.7, 10))
colors_image = plt.cm.plasma(np.linspace(0.3, 1, 10))

for i in range(10):
    y = sigmoid_curve(d_range, gamma1[i], gamma2[i], gamma3[i])
    # Normalize to [0,1] for visualization
    y_norm = y / gamma1[i]
    ax.plot(d_range, y_norm, color=colors_scalar[i], label=biomarker_names[i], lw=2)

for i in range(10, 20):
    y = sigmoid_curve(d_range, gamma1[i], gamma2[i], gamma3[i])
    y_norm = y / gamma1[i]
    ax.plot(d_range, y_norm, color=colors_image[i-10], 
            label=biomarker_names[i], lw=1.5, linestyle='--')

ax.axvline(0, color='gray', alpha=0.3, lw=1)
ax.set_xlabel("Estimated Disease Progression D")
ax.set_ylabel("Biomarker Abnormality (normalized)")
ax.set_title("Estimated biomarker progression curves (k=20: 10 scalar + 10 image PC)")
ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
plt.tight_layout()
plt.savefig("figure_trajectories_k20.pdf", bbox_inches='tight')
plt.savefig("figure_trajectories_k20.png", dpi=150, bbox_inches='tight')
print("Saved figure_trajectories_k20.pdf/png")

================================================================
Step 3.2: Ordering table — γ_3 sorted with rankings
================================================================

# Sort biomarkers by γ_3 (earliest → latest in cascade)
ordering_df = pd.DataFrame({
    'biomarker': biomarker_names,
    'gamma_3': gamma3,
    'gamma_2': gamma2,
    'gamma_1': gamma1,
    'is_image': [False]*10 + [True]*10,
})
ordering_df = ordering_df.sort_values('gamma_3').reset_index(drop=True)
ordering_df['rank'] = ordering_df.index + 1

print(f"\n=== Ordering by γ_3 (cascade position) ===")
print(ordering_df.to_string())

ordering_df.to_csv("ordering_k20.csv", index=False)

# Highlight: where do image PCs fall?
print(f"\n=== Image PC ranking summary ===")
img_ranks = ordering_df[ordering_df['is_image']]['rank'].values
print(f"Image PC ranks (1=earliest, 20=latest): {sorted(img_ranks.tolist())}")
print(f"  Mean rank:   {img_ranks.mean():.1f}")
print(f"  Median rank: {np.median(img_ranks):.1f}")

# Image PC vs CSF / MRI / cognitive position
csf_idx = [biomarker_names.index(b) for b in ['ABETA','PTAU','TAU']]
mri_idx = [biomarker_names.index(b) for b in ['biec.thik','bihippo','biec.vol','MTL1']]
cog_idx = [biomarker_names.index(b) for b in ['MMSCORE','logmem','DSST']]

print(f"\nDomain γ_3 (mean):")
print(f"  CSF: {gamma3[csf_idx].mean():.3f}")
print(f"  Image PC: {gamma3[10:20].mean():.3f}")
print(f"  MRI scalar: {gamma3[mri_idx].mean():.3f}")
print(f"  Cognitive: {gamma3[cog_idx].mean():.3f}")

================================================================
Step 3.3: Bootstrap CI — γ_3 confidence intervals
================================================================

import os
import glob

bootstrap_files = sorted(glob.glob("bootstrap_output/iter_*/theta_final.csv"))
print(f"\nFound {len(bootstrap_files)} bootstrap iters")

bs_thetas = []
for f in bootstrap_files:
    th = pd.read_csv(f).iloc[:20, :]  # ensure 20 rows
    if len(th) == 20:
        bs_thetas.append(th)

print(f"Valid bootstrap iters: {len(bs_thetas)}")
bs_array = np.array([t.values for t in bs_thetas])  # shape (B, 20, 9)

# γ_3 CI per biomarker
gamma3_bs = bs_array[:, :, 7]  # (B, 20)
print(f"\n=== γ_3 95% Bootstrap CI ===")
print(f"{'Biomarker':<12} {'Main':>8} {'Q2.5':>8} {'Q50':>8} {'Q97.5':>8} {'Width':>8}")
for i, name in enumerate(biomarker_names):
    main_g3 = gamma3[i]
    q025 = np.quantile(gamma3_bs[:, i], 0.025)
    q500 = np.quantile(gamma3_bs[:, i], 0.500)
    q975 = np.quantile(gamma3_bs[:, i], 0.975)
    width = q975 - q025
    sig = "*" if width < 1.0 else " "  # Heuristic: narrow CI = "significant" ordering
    print(f"{name:<12} {main_g3:>+8.3f} {q025:>+8.3f} {q500:>+8.3f} {q975:>+8.3f} {width:>+8.3f} {sig}")

================================================================
Step 3.4: Ordering uncertainty heatmap (paper Fig 2 style)
================================================================

# Per bootstrap iter, compute rank of each biomarker
bs_ranks = np.zeros_like(gamma3_bs)  # (B, 20)
for b in range(gamma3_bs.shape[0]):
    bs_ranks[b] = np.argsort(np.argsort(gamma3_bs[b])) + 1  # rank 1-20

# Heatmap: biomarker × rank
heatmap = np.zeros((20, 20))
for i in range(20):
    for r in range(1, 21):
        heatmap[i, r-1] = np.mean(bs_ranks[:, i] == r)

# Sort biomarkers by main fit rank
main_ranks = np.argsort(np.argsort(gamma3)) + 1
sort_idx = np.argsort(main_ranks)
heatmap_sorted = heatmap[sort_idx]
names_sorted = [biomarker_names[i] for i in sort_idx]

fig, ax = plt.subplots(figsize=(10, 8))
im = ax.imshow(heatmap_sorted, aspect='auto', cmap='Blues', vmin=0, vmax=heatmap.max())
ax.set_xticks(range(20))
ax.set_xticklabels(range(1, 21))
ax.set_yticks(range(20))
ax.set_yticklabels(names_sorted)
ax.set_xlabel("Bootstrap rank")
ax.set_ylabel("Biomarker (sorted by main fit γ_3)")
ax.set_title("Bootstrap distribution of γ_3 ranks (k=20: 10 scalar + 10 image PC)")
plt.colorbar(im, label="Proportion of bootstrap iters")
plt.tight_layout()
plt.savefig("figure_ordering_heatmap_k20.pdf", bbox_inches='tight')
plt.savefig("figure_ordering_heatmap_k20.png", dpi=150, bbox_inches='tight')

================================================================
Step 3.5: Individual D estimation 
================================================================

# 用 main fit estimate per-subject D̂, 跟 Zheyu's d_mod3 比较
# 简化版: Wang model 公式 (4) 的 conditional expectation
# 对每 visit:
#   E[D | Y, X, Z] ≈ integral d × f(Y|d) f(d|Z) / f(Y|X,Z) dd
#   
# 这个 需要 d_estimation2.py-style rejection sampling.
# Zheyu 没 share, 但 simplified version 是 grid integration.

# Simplified: per visit, find D maximizing posterior given observed biomarkers
def estimate_d_per_visit(y_obs, x_obs, z_obs, theta, phi, cor_params, K=20):
    """One-visit D estimation via grid search posterior."""
    d_grid = np.linspace(-4, 4, 200)
    
    log_post = np.zeros_like(d_grid)
    for i, d in enumerate(d_grid):
        # Biomarker likelihood: ∏_k N(y_k | β_k·x + γ_k1 / (1+exp(-γ_k2(d-γ_k3))), σ_k)
        for b in range(K):
            if pd.isna(y_obs[b]):
                continue
            beta = theta[b, :5]  # cols 1-5: intercept + 4 covariates
            g1, g2, g3, sigma = theta[b, 5], theta[b, 6], theta[b, 7], theta[b, 8]
            mu = np.dot(beta, x_obs) + g1 / (1 + np.exp(-g2 * (d - g3)))
            log_post[i] += -0.5 * ((y_obs[b] - mu) / sigma) ** 2
        # Prior on d: N(z·α, 1)
        d_mean = np.dot(z_obs, phi)
        log_post[i] += -0.5 * (d - d_mean) ** 2
    
    # Posterior mean (weighted by exp(log_post))
    log_post -= log_post.max()  # normalize for stable exp
    weights = np.exp(log_post)
    weights /= weights.sum()
    d_hat = np.dot(weights, d_grid)
    return d_hat


# Apply to all visits in input data
wang_input = pd.read_csv("wang_input_k20.csv")
print(f"\nEstimating per-visit D̂ for {len(wang_input)} visits...")

theta_arr = main_theta.values
phi_arr = pd.read_csv("adni_k20_main/result/<final_phi_file>").values.flatten()

K = 20
y_cols = list(wang_input.columns[:K])
cov_cols = ['age', 'apoe', 'PTGENDER', 'education']  # 4 covariates

d_hats = []
for i, row in wang_input.iterrows():
    y_obs = row[y_cols].values
    x_obs = np.array([1] + row[cov_cols].tolist())  # add intercept
    z_obs = row[cov_cols[:2]].values  # age, apoe
    d_hat = estimate_d_per_visit(y_obs, x_obs, z_obs, theta_arr, phi_arr, None, K=K)
    d_hats.append(d_hat)
    if i % 500 == 0:
        print(f"  {i} / {len(wang_input)}")

wang_input['d_hat_image_joint'] = d_hats

# Compare with d_mod3 (Zheyu's k=10 estimate)
valid = wang_input.dropna(subset=['d_mod3', 'd_hat_image_joint'])
from scipy.stats import pearsonr, spearmanr

pr, _ = pearsonr(valid['d_mod3'], valid['d_hat_image_joint'])
sr, _ = spearmanr(valid['d_mod3'], valid['d_hat_image_joint'])
print(f"\n=== Image-joint d̂ vs Zheyu's d_mod3 ===")
print(f"  N visits: {len(valid)}")
print(f"  Pearson r: {pr:.4f}")
print(f"  Spearman ρ: {sr:.4f}")

# Where do they disagree?
valid['disagreement'] = valid['d_hat_image_joint'] - valid['d_mod3']
print(f"  Mean diff (image_joint - d_mod3): {valid['disagreement'].mean():+.4f}")
print(f"  Std of diff: {valid['disagreement'].std():.4f}")
print(f"  Largest 10 disagreements (image > Zheyu):")
print(valid.nlargest(10, 'disagreement')[['RID','EXAMDATE.x','dx','d_mod3','d_hat_image_joint']])

# Save full
wang_input.to_csv("d_hat_image_joint_per_visit.csv", index=False)

================================================================
Step 3.6: CN-vs-AD AUC using new d̂
================================================================

from sklearn.metrics import roc_auc_score

bl_per_rid = valid.sort_values('EXAMDATE.x').groupby('RID').first().reset_index()
cn_ad = bl_per_rid[bl_per_rid['dx'].isin(['NORMAL', 'AD'])]
y_cnad = (cn_ad['dx'] == 'AD').astype(int)
auc_new = roc_auc_score(y_cnad, cn_ad['d_hat_image_joint'])
auc_old = roc_auc_score(y_cnad, cn_ad['d_mod3'])
print(f"\n=== CN vs AD baseline AUC ===")
print(f"  Using image-joint d̂:  {auc_new:.3f}")
print(f"  Using Zheyu's d_mod3: {auc_old:.3f}")
print(f"  Improvement: {auc_new - auc_old:+.3f}")

================================================================
STOP. Paste all numbers:
================================================================
  1. Main fit γ_3 table (Step 3.1, 20 biomarker)
  2. Ordering table (Step 3.2)
  3. Image PC γ_3 distribution across cascade
  4. Bootstrap CI for γ_3 (Step 3.3)
  5. Ordering heatmap saved? (Step 3.4)
  6. Pearson r, Spearman ρ d_hat_image_joint vs d_mod3
  7. CN vs AD AUC with new d̂ vs Zheyu's d̂
  8. Generated figures path
================================================================

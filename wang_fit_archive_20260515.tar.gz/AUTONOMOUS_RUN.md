================================================================================
WANG MODEL + IMAGE PC AUTONOMOUS RUN — Complete Pipeline
================================================================================

You are running an end-to-end Wang joint AD progression model fit experiment.
The user has already unzipped wang_image_fit/ to JHPCE working dir. All 
framework code is in place. Your job: run all 4 stages autonomously, submit 
SLURM jobs as needed, monitor completion, and produce final paper-ready output.

================================================================================
PROJECT BACKGROUND (read this carefully before starting)
================================================================================

We extend Wang et al. 2024 AOAS "Joint Modeling of Biomarker Dynamics with a 
Dual Sigmoid Curve in an Unobserved Disease Progression with Inference on 
Temporal Orderings" by adding K=10 image-derived PC features into the joint 
fit, going from k=10 (10 scalar biomarker) to k=20 (10 scalar + 10 image PC).

The 10 image PCs come from:
  - Foundation model (Swin UNETR, BTCV-pretrained, feature_size=48) 
  - Encoded ADNI T1-weighted MRI at 128³ resolution after SyN to MNI
  - ComBat harmonized by SiteID (PTID first 3 digits)
  - Standardized PCA (z-scored, unit variance)
  - Top 10 PCs by variance

Prior analysis (Path A, simple image→d_mod3 regression) showed:
  - R² = 0.09 (weak)
  - CN-vs-AD AUC = 0.80 (moderate)
  - This is too weak for a substantive paper

Path B (this pipeline): joint refit Wang model with image PCs as additional 
biomarker. Goal: get image PCs sigmoid params (γ_3 = cascade position, 
γ_2 = transition rate) jointly estimated with scalar biomarker. Compare 
ordering with vs without image PCs.

Three paper claims to validate:
  Claim 1: Adding image PCs preserves scalar biomarker ordering
  Claim 2: Some image PCs occupy interpretable cascade positions (novel)
  Claim 3: Image-derived D̂ improves individual prediction vs scalar-only

================================================================================
EXPECTED RUNTIME
================================================================================

Step 0 (setup + verify):            30 min
Step 1 (k=10 reproduce):            1-2 hour wall (single SLURM job)
Step 2 (k=20 main fit):             8-24 hour wall (single SLURM job)
Step 2.5 (bootstrap 100 iter):      8-24 hour wall (SLURM array, 25 concurrent)
Step 3 (evaluate + figures):        1-2 hour wall

Total: 1-3 days wall time. You can submit and wait between stages.

================================================================================
FILES IN PLACE (user already unzipped)
================================================================================

wang_image_fit/
├── README.md
├── ADNI/
│   ├── theta.csv         (20 rows: 10 Zheyu init + 10 image PC default init)
│   ├── phi.csv           (alpha for age, apoe on D)
│   └── cor.csv           (6 correlation params, image PCs assumed indep)
├── ADNI_k10/
│   ├── theta.csv         (Zheyu's original 10-biomarker init)
│   ├── phi.csv
│   └── cor.csv
├── R/
│   ├── ADLDA_funs.R      (Zheyu's newer 395-line version, has IDs+w4 params)
│   ├── newton_iter.R     (Zheyu's newer 186-line version)
│   ├── test0822.cpp      (Wang ADNI cpp, used by Zheyu's converge.R)
│   ├── converge_k10_verify.R   (modified converge.R for k=10 reproduce)
│   └── converge_k20.R          (modified converge.R for k=20 image fit)
├── scripts/
│   ├── verify_columns.py       (sanity check)
│   ├── build_wang_input.py     (build fit-ready CSV)
│   ├── run_r_fit.py            (subprocess Rscript wrapper)
│   └── run_bootstrap.py        (bootstrap single-iter)
└── prompts/                    (legacy human-readable docs, you can ignore)

YOU MUST verify these files exist before starting. Run:
  cd ~/work/wang_fit_run   # or wherever you unzipped
  ls -la
  find . -name "*.R" -o -name "*.py" -o -name "*.cpp" -o -name "*.csv" | sort

================================================================================
KEY DATA INPUTS (find their location, don't assume)
================================================================================

These MUST be located before you start. They're produced by earlier work:

1. D_with_image_paths.csv 
   - Master merge of D + scalar biomarker + image paths
   - Likely path: data/master_smri/ or in user's project root
   - Run: find / -name "D_with_image_paths.csv" 2>/dev/null | head -3
   - If found in different location: ln -s /actual/path/D_with_image_paths.csv .

2. data/embeddings_128/ (image PCA features)
   - swin_combat_pca_z_train.npy   shape (1709, 767)
   - swin_combat_pca_z_test.npy    shape (390, 767)
   - swin_combat_pca_z_train_ids.npy
   - swin_combat_pca_z_test_ids.npy
   - Run: find / -name "swin_combat_pca_z_train.npy" 2>/dev/null | head -3
   - Create symbolic link: mkdir -p data && ln -s /actual/path/embeddings_128 data/embeddings_128

DO NOT COPY large files. Use ln -s.

================================================================================
WORKING DIR EXPECTATION
================================================================================

You should be in ~/work/wang_fit_run/ or similar JHPCE standard location.
Run `pwd` to confirm. If not in expected dir, cd there first.

All commands assume this is your working dir. R scripts also expect this:
- ADNI/ in working dir (init values)
- R machinery files (ADLDA_funs.R, newton_iter.R, test0822.cpp) in working dir
  (NOT in R/ subdir — R scripts source them with relative path "")

So you'll need to either:
(a) Copy R/*.R and R/*.cpp to working dir root, OR
(b) Symlink them: cd working dir && ln -s R/*.R . && ln -s R/*.cpp .

I recommend (b). Decide and execute.

================================================================================
SECTION 0: PRE-FLIGHT (30 min, must pass before continuing)
================================================================================

Step 0.1: Verify file structure
─────────────────────────────────

```bash
cd ~/work/wang_fit_run   # adjust if needed
pwd
ls -la

# Required files (all must exist):
for f in ADNI/theta.csv ADNI/phi.csv ADNI/cor.csv \
         ADNI_k10/theta.csv \
         R/ADLDA_funs.R R/newton_iter.R R/test0822.cpp \
         R/converge_k10_verify.R R/converge_k20.R \
         scripts/build_wang_input.py scripts/verify_columns.py \
         scripts/run_r_fit.py scripts/run_bootstrap.py; do
  if [ -f "$f" ]; then
    echo "OK  $f"
  else
    echo "!! MISSING: $f"
  fi
done
```

If any missing: stop, ask user.

Step 0.2: Symlink R machinery to working dir root
─────────────────────────────────────────────────

```bash
# R scripts source files from working dir (relative path "")
# So make them visible at working dir root
ln -sf R/ADLDA_funs.R .
ln -sf R/newton_iter.R .
ln -sf R/test0822.cpp .
ln -sf R/converge_k10_verify.R .
ln -sf R/converge_k20.R .
ls -la *.R *.cpp
```

Step 0.3: Locate + symlink data files
─────────────────────────────────────

```bash
# Find D_with_image_paths.csv (may be in user's earlier work)
echo "Searching for D_with_image_paths.csv..."
find / -name "D_with_image_paths.csv" 2>/dev/null | head -3

# Once found, symlink to working dir:
# ln -sf /found/path/D_with_image_paths.csv .

# Find image PCA embeddings
echo "Searching for swin_combat_pca_z_train.npy..."
find / -name "swin_combat_pca_z_train.npy" 2>/dev/null | head -3

# Symlink the parent dir:
# mkdir -p data
# ln -sf /found/path/to/embeddings_128 data/embeddings_128
```

Verify:
```bash
ls -la D_with_image_paths.csv
ls -la data/embeddings_128/
```

Step 0.4: Verify column alignment (30 sec sanity)
─────────────────────────────────────────────────

```bash
python scripts/verify_columns.py D_with_image_paths.csv data/embeddings_128
```

CRITICAL PASS CRITERIA:
  ✓ All 10 scalar biomarker columns present (MMSCORE, logmem, DSST, biec.thik,
    bihippo, biec.vol, MTL1, TAU, PTAU, ABETA)
  ✓ All 4 covariate columns present (age, apoe, PTGENDER, education)
  ✓ Image_Data_ID column present
  ✓ Overlap rate (PC ids ∩ CSV ids) > 90%
  ✓ Z_train shape ~(1709, 767), Z_test shape ~(390, 767)

If overlap < 90%, STOP. Print ID format samples and ask user.

Step 0.5: Verify R + packages
──────────────────────────────

```bash
# Check R available
which R
R --version

# Test required packages
R --no-save <<'EOF'
required <- c("statmod","MASS","boot","Rcpp","Matrix","mvtnorm",
              "dplyr","common","logr")
missing <- c()
for (p in required) {
    if (!require(p, character.only=TRUE, quietly=TRUE)) {
        missing <- c(missing, p)
    }
}
if (length(missing) > 0) {
    cat("MISSING PACKAGES:", paste(missing, collapse=", "), "\n")
    cat("Attempting install...\n")
    install.packages(missing, repos="https://cran.r-project.org")
} else {
    cat("All packages OK\n")
}
EOF
```

If install fails on JHPCE (likely due to permissions), try:
  module load R
  Then retry. If still fails, contact bithelp@lists.jh.edu (user noted this).

Step 0.6: Test cpp compilation
───────────────────────────────

```bash
# Critical test: does test0822.cpp compile via Rcpp?
R --no-save <<'EOF'
library(Rcpp)
tryCatch({
    sourceCpp("test0822.cpp")
    cat("✓ test0822.cpp compiled successfully\n")
}, error = function(e) {
    cat("!! cpp compile FAILED:\n")
    print(e)
    cat("\nLikely cause: missing Eigen/RcppEigen, or g++ version mismatch.\n")
    cat("On JHPCE, try: module load gcc; module load r-rcpp; module load r-rcppeigen\n")
})
EOF
```

If cpp compile fails: STOP, this blocks everything. Try modules, then ask user.

If all Section 0 checks pass, print:
  "✓ Pre-flight OK, proceeding to Step 1"
And continue.

================================================================================
SECTION 1: STEP 1 — k=10 verify fit (1-2 hour wall)
================================================================================

GOAL: Reproduce Zheyu's k=10 (10 scalar biomarker) fit to confirm R machinery 
works + data prep is correct. Init values = Zheyu's converged values, so fit 
should converge in <30 iter.

Step 1.1: Build wang_input_k10.csv (no image PCs)
─────────────────────────────────────────────────

```bash
python scripts/build_wang_input.py \
  --d_path D_with_image_paths.csv \
  --K 0 \
  --out wang_input_k10.csv
```

Expected output:
  - Shape: (~12000, ~25)
  - First 10 cols: scalar biomarker (MMSCORE through ABETA)
  - Cols 11-14: covariate (age, apoe, PTGENDER, education)
  - Cols 15+: metadata (RID, EXAMDATE, dx, d_mod3, sMRI_path, etc.)
  - "Image PC matched" line should NOT appear (K=0)

Verify output:
```bash
head -1 wang_input_k10.csv | tr ',' '\n' | head -15
wc -l wang_input_k10.csv
python -c "import pandas as pd; df=pd.read_csv('wang_input_k10.csv'); print(df.shape); print(df.columns[:14].tolist())"
```

Step 1.2: Submit Step 1 SLURM job
──────────────────────────────────

Create submission script:

```bash
cat > submit_step1.sh <<'EOF'
#!/bin/bash
#SBATCH -J wang_k10_verify
#SBATCH -p shared
#SBATCH -t 02:00:00
#SBATCH -c 1
#SBATCH --mem=16G
#SBATCH -o logs/step1_%j.out
#SBATCH -e logs/step1_%j.err

cd $SLURM_SUBMIT_DIR
mkdir -p logs

echo "=== Step 1: k=10 verify fit ==="
echo "Started: $(date)"
echo "Working dir: $(pwd)"
echo ""

Rscript R/converge_k10_verify.R \
    wang_input_k10.csv \
    adni_k10_verify/ \
    ADNI_k10/

echo ""
echo "Done: $(date)"
EOF
chmod +x submit_step1.sh
mkdir -p logs
```

Submit:
```bash
sbatch submit_step1.sh
# Note returned job id, e.g.: "Submitted batch job 12345"
```

Step 1.3: Monitor Step 1
────────────────────────

```bash
# Check status (don't poll faster than every 5 min)
squeue -u $USER

# Watch progress in real time:
# tail -f logs/step1_<jobid>.out
```

Wait for completion. Job should finish in 1-2 hours. If still running after 
3 hours, something is wrong — investigate.

DO NOT block on this synchronously. While waiting, you can prepare Step 2 
inputs (Step 2.1 below) since it's independent.

Step 1.4: Parse + verify Step 1 output
──────────────────────────────────────

After job completes:

```python
import pandas as pd
import numpy as np
import glob

# Find result files
result_dir = "adni_k10_verify/result"
theta_files = sorted(glob.glob(f"{result_dir}/*theta*.csv"))
phi_files = sorted(glob.glob(f"{result_dir}/*phi*.csv"))
cor_files = sorted(glob.glob(f"{result_dir}/*cor*.csv"))

print(f"Iterations completed: {len(theta_files)}")

# Load final theta
final_theta_k10 = pd.read_csv(theta_files[-1])
print(f"\nFinal theta shape: {final_theta_k10.shape}")
print(f"Columns: {final_theta_k10.columns.tolist()}")

biomarker_names = ['MMSCORE','logmem','DSST','biec.thik','bihippo',
                   'biec.vol','MTL1','TAU','PTAU','ABETA']

# γ_3 column is index 7 (intercept, age, apoe, gender, edu, γ_1, γ_2, γ_3, σ)
zheyu_init_g3 = [2.534, 2.242, 2.375, 1.610, 2.041, 1.712, 1.809, 1.000, 0.533, 0.254]
final_g3 = final_theta_k10.iloc[:, 7].values

print(f"\n=== Step 1 verify: γ_3 comparison ===")
print(f"{'Biomarker':<12} {'Zheyu init':>11} {'k=10 fit':>10} {'Diff':>+8}")
for i, name in enumerate(biomarker_names):
    diff = final_g3[i] - zheyu_init_g3[i]
    print(f"{name:<12} {zheyu_init_g3[i]:>11.3f} {final_g3[i]:>10.3f} {diff:>+8.3f}")

# Ordering check
ordering = np.argsort(final_g3)
print(f"\nFit ordering (earliest→latest): {[biomarker_names[i] for i in ordering]}")
print(f"Expected from paper:             ['ABETA','PTAU','TAU','biec.thik','biec.vol',")
print(f"                                  'MTL1','bihippo','logmem','DSST','MMSCORE']")
```

PASS CRITERIA (must all be true):
  ✓ Fit converged (no NaN/Inf in final theta)
  ✓ γ_3 differences from init all < 0.3
  ✓ ABETA has smallest γ_3 (earliest in cascade)
  ✓ MMSCORE has largest γ_3 (latest in cascade)
  ✓ Domain ordering preserved: CSF < MRI < cognitive

If PASS: print "✓ Step 1 verified, proceeding to Step 2"
If FAIL: STOP, paste error log, ask user.

================================================================================
SECTION 2: STEP 2 — k=20 main fit (8-24 hour wall)
================================================================================

GOAL: Joint fit Wang model with 10 scalar + 10 image PCs as biomarker.
This is the main scientific contribution.

Step 2.1: Build wang_input_k20.csv (with 10 image PC)
─────────────────────────────────────────────────────

(Can run in parallel with Step 1 wait)

```bash
python scripts/build_wang_input.py \
  --d_path D_with_image_paths.csv \
  --embed_dir data/embeddings_128 \
  --K 10 \
  --out wang_input_k20.csv
```

Expected:
  - Shape: similar rows to k=10, but 10 more columns
  - First 10 cols: scalar biomarker
  - Cols 11-20: image_pc_1 through image_pc_10
  - "Image PC matched: ~3000/~12000 rows (~25%)" line
  - Rest of visits have NaN for image PC columns (expected, Wang fit handles)

Verify:
```bash
python -c "
import pandas as pd
df = pd.read_csv('wang_input_k20.csv')
print(f'Shape: {df.shape}')
print(f'Cols 1-20:', df.columns[:20].tolist())
print(f'Image PC matched (non-NA in image_pc_1):', df['image_pc_1'].notna().sum())
print(f'Sample biomarker + image PC values:')
print(df.iloc[:3, :20].to_string())
"
```

Step 2.2: Submit Step 2 SLURM job (main fit)
─────────────────────────────────────────────

Only proceed if Step 1 passed.

```bash
cat > submit_step2.sh <<'EOF'
#!/bin/bash
#SBATCH -J wang_k20_main
#SBATCH -p shared
#SBATCH -t 24:00:00
#SBATCH -c 1
#SBATCH --mem=24G
#SBATCH -o logs/step2_%j.out
#SBATCH -e logs/step2_%j.err

cd $SLURM_SUBMIT_DIR
mkdir -p logs

echo "=== Step 2: k=20 main fit ==="
echo "Started: $(date)"
echo "Working dir: $(pwd)"
echo ""

Rscript R/converge_k20.R \
    wang_input_k20.csv \
    adni_k20_main/ \
    ADNI/

echo ""
echo "Done: $(date)"
EOF
chmod +x submit_step2.sh
```

Submit:
```bash
sbatch submit_step2.sh
# Note returned job id
```

Step 2.3: Monitor Step 2
────────────────────────

```bash
# Job may run 8-24 hours, do not poll
squeue -u $USER
tail logs/step2_<jobid>.out  # check periodically
```

Step 2.4: After Step 2 completes, sanity check
───────────────────────────────────────────────

```python
import pandas as pd
import numpy as np
import glob

result_dir = "adni_k20_main/result"
theta_files = sorted(glob.glob(f"{result_dir}/*theta*.csv"))
print(f"Iterations completed: {len(theta_files)}")

theta_k20 = pd.read_csv(theta_files[-1])
print(f"Shape: {theta_k20.shape}")

biomarker_names_k20 = ['MMSCORE','logmem','DSST','biec.thik','bihippo',
                       'biec.vol','MTL1','TAU','PTAU','ABETA',
                       'IMG_PC1','IMG_PC2','IMG_PC3','IMG_PC4','IMG_PC5',
                       'IMG_PC6','IMG_PC7','IMG_PC8','IMG_PC9','IMG_PC10']

# Print all 20 biomarker params
print(f"\n=== k=20 final theta ===")
print(f"{'Biomarker':<12} {'γ_1':>8} {'γ_2':>8} {'γ_3':>+8} {'σ':>6}")
for i, name in enumerate(biomarker_names_k20):
    g1, g2, g3, sig = theta_k20.iloc[i, 5:9]
    print(f"{name:<12} {g1:>8.3f} {g2:>8.3f} {g3:>+8.3f} {sig:>6.3f}")

# Image PC γ_2 sanity (flat sigmoid = γ_2 < 1, saturated = > 9)
img_g2 = theta_k20.iloc[10:20, 6].values
print(f"\n=== Image PC γ_2 health ===")
print(f"  Flat sigmoid (γ_2 < 1):     {(img_g2 < 1).sum()}/10")
print(f"  Saturated (γ_2 > 9):        {(img_g2 > 9).sum()}/10")
print(f"  Healthy (γ_2 in [2, 8]):   {((img_g2 >= 2) & (img_g2 <= 8)).sum()}/10")
```

PASS CRITERIA:
  ✓ Final theta has 20 rows, no NaN
  ✓ Scalar γ_3 (rows 1-10) close to Step 1 k=10 fit (within 0.3 each)
  ✓ At least 3/10 image PC have γ_2 in [2, 8] (healthy ordering)
  ✓ Log shows likelihood improved over iterations (monotonic ideally)

If fewer than 3 healthy image PC γ_2: still proceed but flag as caveat.

================================================================================
SECTION 3: STEP 2.5 — Bootstrap 100 iter (SLURM array)
================================================================================

GOAL: Bootstrap CI for γ_3 across 20 biomarker. 100 iter parallel via SLURM 
array, throttled to 25 concurrent.

Step 2.5.1: Create bootstrap submission
────────────────────────────────────────

```bash
cat > submit_bootstrap.sh <<'EOF'
#!/bin/bash
#SBATCH -J wang_bootstrap
#SBATCH -p shared
#SBATCH -t 08:00:00
#SBATCH -c 1
#SBATCH --mem=16G
#SBATCH -o logs/bs_%A_%a.out
#SBATCH -e logs/bs_%A_%a.err

cd $SLURM_SUBMIT_DIR
mkdir -p logs bootstrap_output

# Use main fit init for faster bootstrap convergence (init dir = ADNI/)
python scripts/run_bootstrap.py \
    --iter $SLURM_ARRAY_TASK_ID \
    --seed $SLURM_ARRAY_TASK_ID \
    --base_input wang_input_k20.csv \
    --r_script R/converge_k20.R \
    --init_dir ADNI \
    --output_root bootstrap_output
EOF
chmod +x submit_bootstrap.sh
```

Step 2.5.2: Submit array (1-100, throttle 25 concurrent)
─────────────────────────────────────────────────────────

```bash
sbatch -a 1-100%25 submit_bootstrap.sh
# Note array job ID
```

Step 2.5.3: Monitor bootstrap
──────────────────────────────

```bash
# Check completion count over time:
while true; do
    completed=$(ls -d bootstrap_output/iter_* 2>/dev/null | wc -l)
    queued=$(squeue -u $USER -h | wc -l)
    echo "$(date): completed $completed/100, queued $queued"
    if [ $completed -ge 100 ] || [ $queued -eq 0 ]; then break; fi
    sleep 600  # check every 10 min
done
```

Some iters may fail (10-20% rate is normal for NR optimization). After all 
jobs done, count successes:

```bash
successes=$(ls -d bootstrap_output/iter_* 2>/dev/null | wc -l)
failures=$(grep -l "Error" logs/bs_*.err 2>/dev/null | wc -l)
echo "Bootstrap: $successes successes, $failures failures"
```

PASS CRITERIA:
  ✓ At least 50 successful bootstrap iters (preferably 80+)
  ✓ Failed iter logs investigated (most likely NR divergence — acceptable)

If < 50 successes: try resubmitting failed iters once (use different seed).

================================================================================
SECTION 4: STEP 3 — Evaluation + Comparison + Figures
================================================================================

GOAL: Compare k=10 vs k=20 fit, compute bootstrap CI, individual D̂ estimation, 
downstream prediction AUCs, generate paper figures.

Step 3.1: Create evaluation script
───────────────────────────────────

```bash
cat > scripts/evaluate_with_vs_without_image.py <<'EOF'
"""
Step 3 full evaluation: with vs without image PCs.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import glob
from pathlib import Path
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import roc_auc_score

BIO_K10 = ['MMSCORE','logmem','DSST','biec.thik','bihippo',
           'biec.vol','MTL1','TAU','PTAU','ABETA']
BIO_K20 = BIO_K10 + [f'IMG_PC{i+1}' for i in range(10)]


def find_final(pattern):
    files = sorted(glob.glob(pattern))
    if not files:
        raise FileNotFoundError(f"No files match {pattern}")
    return files[-1]


def estimate_d_per_visit(y_obs, x_obs, z_obs, theta, phi, K, d_grid=None):
    """Posterior mean of D via grid integration (Wang Eq 11 approximation)."""
    if d_grid is None:
        d_grid = np.linspace(-4, 4, 200)
    
    log_post = np.zeros_like(d_grid)
    for i, d in enumerate(d_grid):
        for b in range(K):
            yb = y_obs[b]
            if pd.isna(yb):
                continue
            beta = theta[b, :5]
            g1, g2, g3, sigma = theta[b, 5], theta[b, 6], theta[b, 7], theta[b, 8]
            if sigma <= 0:
                continue
            mu = np.dot(beta, x_obs) + g1 / (1 + np.exp(-g2 * (d - g3)))
            log_post[i] += -0.5 * ((yb - mu) / sigma) ** 2
        d_mean = np.dot(z_obs, phi)
        log_post[i] += -0.5 * (d - d_mean) ** 2
    
    log_post -= log_post.max()
    w = np.exp(log_post)
    w_sum = w.sum()
    if w_sum == 0 or not np.isfinite(w_sum):
        return np.nan
    w /= w_sum
    return float(np.dot(w, d_grid))


def sigmoid(d, g1, g2, g3):
    return g1 / (1 + np.exp(-g2 * (d - g3)))


def main():
    print("="*80)
    print("Step 3 Evaluation: with vs without image PCs")
    print("="*80)
    
    # === Load fits ===
    theta_k10 = pd.read_csv(find_final("adni_k10_verify/result/*theta*.csv"))
    theta_k20 = pd.read_csv(find_final("adni_k20_main/result/*theta*.csv"))
    phi_k10 = pd.read_csv(find_final("adni_k10_verify/result/*phi*.csv"), header=None).values.flatten()
    phi_k20 = pd.read_csv(find_final("adni_k20_main/result/*phi*.csv"), header=None).values.flatten()
    
    print(f"\nFinal fits loaded:")
    print(f"  theta_k10: {theta_k10.shape}, phi_k10: {phi_k10}")
    print(f"  theta_k20: {theta_k20.shape}, phi_k20: {phi_k20}")
    
    # === Claim 1: scalar ordering stability ===
    g3_k10 = theta_k10.iloc[:10, 7].values
    g3_k20_scalar = theta_k20.iloc[:10, 7].values
    
    print(f"\n=== Claim 1: Scalar biomarker γ_3 — k=10 vs k=20 ===")
    print(f"{'Biomarker':<12} {'k=10 γ_3':>10} {'k=20 γ_3':>10} {'Diff':>+8}")
    for i, name in enumerate(BIO_K10):
        diff = g3_k20_scalar[i] - g3_k10[i]
        print(f"{name:<12} {g3_k10[i]:>+10.3f} {g3_k20_scalar[i]:>+10.3f} {diff:>+8.3f}")
    
    rank_k10 = np.argsort(np.argsort(g3_k10)) + 1
    rank_k20 = np.argsort(np.argsort(g3_k20_scalar)) + 1
    if np.array_equal(rank_k10, rank_k20):
        print(f"\n✓ CLAIM 1: Scalar ordering UNCHANGED")
    else:
        print(f"\n⚠ CLAIM 1: Scalar ordering SHIFTED")
    
    # === Claim 2: image PC cascade position ===
    g3_all = theta_k20.iloc[:20, 7].values
    g2_all = theta_k20.iloc[:20, 6].values
    rank_all = np.argsort(np.argsort(g3_all)) + 1
    
    print(f"\n=== Claim 2: Full k=20 cascade (sorted by γ_3) ===")
    sorted_idx = np.argsort(g3_all)
    print(f"{'Rank':>4} {'Biomarker':<12} {'γ_3':>+8} {'γ_2':>+8} {'Domain':>10}")
    for rank, idx in enumerate(sorted_idx, 1):
        domain = ("cognitive" if idx < 3 else 
                  "MRI" if idx < 7 else 
                  "CSF" if idx < 10 else "image PC")
        print(f"{rank:>4} {BIO_K20[idx]:<12} {g3_all[idx]:>+8.3f} {g2_all[idx]:>+8.3f} {domain:>10}")
    
    img_ranks = rank_all[10:20]
    img_g2 = g2_all[10:20]
    healthy = (img_g2 >= 2) & (img_g2 <= 8)
    print(f"\n  Image PC distribution: early={sum(img_ranks <= 7)}, mid={sum((img_ranks > 7) & (img_ranks <= 14))}, late={sum(img_ranks > 14)}")
    print(f"  Healthy γ_2 (in [2,8]): {healthy.sum()}/10")
    
    # === Bootstrap CI ===
    bs_files = sorted(glob.glob("bootstrap_output/iter_*/theta_final.csv"))
    bs_thetas = []
    for f in bs_files:
        try:
            th = pd.read_csv(f)
            if len(th) == 20 and th.shape[1] >= 9:
                bs_thetas.append(th.values)
        except Exception:
            pass
    bs_array = np.array(bs_thetas)
    print(f"\n=== Bootstrap: {len(bs_array)} valid iters / {len(bs_files)} attempted ===")
    
    if len(bs_array) >= 30:
        gamma3_bs = bs_array[:, :, 7]
        print(f"\n=== γ_3 95% Bootstrap CI ===")
        print(f"{'Biomarker':<12} {'Main':>+8} {'Q2.5':>+8} {'Q50':>+8} {'Q97.5':>+8} {'Width':>+7} {'Note':>12}")
        ci_table = []
        for i, name in enumerate(BIO_K20):
            main = theta_k20.iloc[i, 7]
            q025, q050, q975 = np.quantile(gamma3_bs[:, i], [0.025, 0.5, 0.975])
            width = q975 - q025
            note = "tight" if width < 1.0 else ("wide" if width < 2.0 else "very-wide")
            if i >= 10:
                if g2_all[i] < 1.0: note = "flat-sig"
                elif g2_all[i] > 9.0: note = "saturated"
            ci_table.append({'biomarker': name, 'main_g3': main, 'q025': q025, 
                            'q050': q050, 'q975': q975, 'width': width, 'note': note})
            print(f"{name:<12} {main:>+8.3f} {q025:>+8.3f} {q050:>+8.3f} {q975:>+8.3f} {width:>7.3f} {note:>12}")
        pd.DataFrame(ci_table).to_csv("bootstrap_g3_ci.csv", index=False)
    else:
        print(f"  WARNING: too few bootstrap iters ({len(bs_array)} < 30), skipping CI")
    
    # === Individual D̂ estimation ===
    print(f"\n=== Estimating individual D̂ per visit (this takes 5-15 min) ===")
    wang_input = pd.read_csv("wang_input_k20.csv")
    print(f"  Input: {len(wang_input)} visits")
    
    theta_k10_arr = theta_k10.values
    theta_k20_arr = theta_k20.values
    cov_cols = ['age', 'apoe', 'PTGENDER', 'education']
    y_cols_k10 = list(wang_input.columns[:10])
    y_cols_k20 = list(wang_input.columns[:20])
    
    d_hat_k10 = np.full(len(wang_input), np.nan)
    d_hat_k20 = np.full(len(wang_input), np.nan)
    
    for i, row in wang_input.iterrows():
        try:
            x_obs = np.array([1.0] + [row[c] for c in cov_cols])
            z_obs = np.array([row[cov_cols[0]], row[cov_cols[1]]])
            
            d_hat_k10[i] = estimate_d_per_visit(
                row[y_cols_k10].values.astype(float),
                x_obs, z_obs, theta_k10_arr, phi_k10, K=10
            )
            d_hat_k20[i] = estimate_d_per_visit(
                row[y_cols_k20].values.astype(float),
                x_obs, z_obs, theta_k20_arr, phi_k20, K=20
            )
        except Exception:
            pass
        
        if (i+1) % 1000 == 0:
            print(f"    {i+1} / {len(wang_input)}")
    
    wang_input['d_hat_k10'] = d_hat_k10
    wang_input['d_hat_k20'] = d_hat_k20
    
    # === D̂ comparison ===
    valid = wang_input.dropna(subset=['d_hat_k10', 'd_hat_k20', 'd_mod3'])
    print(f"\n=== Individual D̂ comparison ===")
    print(f"  N valid visits: {len(valid)}")
    
    pr_k10_z, _ = pearsonr(valid['d_hat_k10'], valid['d_mod3'])
    pr_k20_k10, _ = pearsonr(valid['d_hat_k20'], valid['d_hat_k10'])
    sr_k20_k10, _ = spearmanr(valid['d_hat_k20'], valid['d_hat_k10'])
    
    print(f"  k=10 D̂ vs Zheyu d_mod3 (sanity): Pearson={pr_k10_z:.4f}")
    print(f"  k=20 D̂ vs k=10 D̂:               Pearson={pr_k20_k10:.4f}, Spearman={sr_k20_k10:.4f}")
    
    valid['d_diff'] = valid['d_hat_k20'] - valid['d_hat_k10']
    print(f"  d_diff (k=20 - k=10): mean={valid['d_diff'].mean():+.4f}, std={valid['d_diff'].std():.4f}")
    print(f"  |diff| > 0.3: {(valid['d_diff'].abs() > 0.3).sum()} ({(valid['d_diff'].abs() > 0.3).sum()/len(valid)*100:.1f}%)")
    print(f"  |diff| > 0.5: {(valid['d_diff'].abs() > 0.5).sum()} ({(valid['d_diff'].abs() > 0.5).sum()/len(valid)*100:.1f}%)")
    
    # === Claim 3: downstream AUC ===
    bl = valid.sort_values('EXAMDATE.x').groupby('RID').first().reset_index()
    cn_ad = bl[bl['dx'].isin(['NORMAL', 'AD'])]
    
    print(f"\n=== Claim 3: CN vs AD baseline AUC (N={len(cn_ad)}) ===")
    if (cn_ad['dx'] == 'AD').sum() >= 5:
        y = (cn_ad['dx'] == 'AD').astype(int)
        auc_k10 = roc_auc_score(y, cn_ad['d_hat_k10'])
        auc_k20 = roc_auc_score(y, cn_ad['d_hat_k20'])
        auc_zheyu = roc_auc_score(y, cn_ad['d_mod3'])
        print(f"  d_hat_k10:  AUC = {auc_k10:.3f}")
        print(f"  d_hat_k20:  AUC = {auc_k20:.3f}  (improvement: {auc_k20-auc_k10:+.3f})")
        print(f"  d_mod3:     AUC = {auc_zheyu:.3f}")
    
    # MCI conversion
    def label_conversion(df):
        df = df.copy()
        df['EXAMDATE.x'] = pd.to_datetime(df['EXAMDATE.x'])
        df = df.sort_values(['RID', 'EXAMDATE.x'])
        out = []
        for rid, g in df.groupby('RID'):
            bl_r = g.iloc[0]
            if bl_r['dx'] != 'MCI': continue
            target = bl_r['EXAMDATE.x'] + pd.DateOffset(years=2)
            fu = g[(g['EXAMDATE.x'] > bl_r['EXAMDATE.x']) & (g['EXAMDATE.x'] <= target)]
            out.append({'RID': rid, 'converted_2y': int((fu['dx']=='AD').any())})
        return pd.DataFrame(out)
    
    conv = label_conversion(wang_input)
    print(f"\n=== MCI→AD 2y conversion (N MCI={len(conv)}, converters={conv['converted_2y'].sum()}) ===")
    if conv['converted_2y'].sum() >= 5:
        bl_mci = bl[bl['dx'] == 'MCI'].merge(conv, on='RID')
        y_conv = bl_mci['converted_2y']
        auc_c_k10 = roc_auc_score(y_conv, bl_mci['d_hat_k10'])
        auc_c_k20 = roc_auc_score(y_conv, bl_mci['d_hat_k20'])
        print(f"  d_hat_k10:  AUC = {auc_c_k10:.3f}")
        print(f"  d_hat_k20:  AUC = {auc_c_k20:.3f}  (improvement: {auc_c_k20-auc_c_k10:+.3f})")
    
    # === Save outputs ===
    keep = ['RID','EXAMDATE.x','dx','d_mod3','d_hat_k10','d_hat_k20','d_diff']
    keep += [c for c in ['META_TEMPORAL_SUVR','CENTILOIDS','SUMMARY_SUVR'] if c in valid.columns]
    valid[keep].to_csv("d_hat_comparison.csv", index=False)
    print(f"\n  Saved: d_hat_comparison.csv")
    
    # === Figures ===
    print(f"\n=== Generating figures ===")
    
    # Figure 1: Trajectory curves (20 biomarker)
    d_range = np.linspace(-3, 4, 200)
    fig, ax = plt.subplots(figsize=(11, 7))
    c1 = plt.cm.viridis(np.linspace(0.05, 0.75, 10))
    c2 = plt.cm.plasma(np.linspace(0.3, 0.95, 10))
    for i in range(10):
        g1, g2, g3 = theta_k20.iloc[i, 5:8]
        y = sigmoid(d_range, g1, g2, g3) / max(g1, 1e-6)
        ax.plot(d_range, y, color=c1[i], label=BIO_K10[i], lw=2)
    for i in range(10):
        g1, g2, g3 = theta_k20.iloc[10+i, 5:8]
        y = sigmoid(d_range, g1, g2, g3) / max(g1, 1e-6)
        ax.plot(d_range, y, color=c2[i], label=f'IMG_PC{i+1}', lw=1.5, linestyle='--')
    ax.axvline(0, color='gray', alpha=0.3)
    ax.set_xlabel("Estimated Disease Progression D")
    ax.set_ylabel("Biomarker Abnormality (normalized)")
    ax.set_title("Biomarker trajectories (k=20: scalar + image PCs)")
    ax.legend(bbox_to_anchor=(1.02, 1), loc='upper left', fontsize=7)
    plt.tight_layout()
    plt.savefig("figure1_trajectories.png", dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  ✓ figure1_trajectories.png")
    
    # Figure 2: D̂ scatter k=10 vs k=20
    fig, ax = plt.subplots(figsize=(7, 7))
    colors = {'NORMAL': 'C0', 'MCI': 'C1', 'AD': 'C3'}
    for dx, col in colors.items():
        sub = valid[valid['dx'] == dx]
        ax.scatter(sub['d_hat_k10'], sub['d_hat_k20'], c=col, label=dx, s=10, alpha=0.5)
    lim = [valid[['d_hat_k10','d_hat_k20']].min().min(), valid[['d_hat_k10','d_hat_k20']].max().max()]
    ax.plot(lim, lim, 'k--', alpha=0.5)
    ax.set_xlabel("D̂ (k=10, scalar only)")
    ax.set_ylabel("D̂ (k=20, scalar + image)")
    ax.set_title(f"Individual D̂ agreement (Pearson r = {pr_k20_k10:.3f})")
    ax.legend()
    plt.tight_layout()
    plt.savefig("figure2_dhat_scatter.png", dpi=150, bbox_inches='tight')
    plt.close()
    print(f"  ✓ figure2_dhat_scatter.png")
    
    # Figure 3: Ordering heatmap (bootstrap rank distribution)
    if len(bs_array) >= 30:
        gamma3_bs = bs_array[:, :, 7]
        bs_ranks = np.zeros_like(gamma3_bs)
        for b in range(gamma3_bs.shape[0]):
            bs_ranks[b] = np.argsort(np.argsort(gamma3_bs[b])) + 1
        
        heatmap = np.zeros((20, 20))
        for i in range(20):
            for r in range(1, 21):
                heatmap[i, r-1] = np.mean(bs_ranks[:, i] == r)
        
        main_ranks = np.argsort(np.argsort(g3_all)) + 1
        sort_idx = np.argsort(main_ranks)
        heatmap_sorted = heatmap[sort_idx]
        names_sorted = [BIO_K20[i] for i in sort_idx]
        
        fig, ax = plt.subplots(figsize=(10, 8))
        im = ax.imshow(heatmap_sorted, aspect='auto', cmap='Blues', vmin=0, vmax=heatmap.max())
        ax.set_xticks(range(20)); ax.set_xticklabels(range(1, 21))
        ax.set_yticks(range(20)); ax.set_yticklabels(names_sorted)
        ax.set_xlabel("Bootstrap rank (1=earliest, 20=latest)")
        ax.set_ylabel("Biomarker (sorted by main fit γ_3)")
        ax.set_title("Bootstrap distribution of γ_3 ranks (k=20)")
        plt.colorbar(im, label="Proportion of bootstrap iters")
        plt.tight_layout()
        plt.savefig("figure3_ordering_heatmap.png", dpi=150, bbox_inches='tight')
        plt.close()
        print(f"  ✓ figure3_ordering_heatmap.png")
    
    print(f"\n{'='*80}")
    print(f"Step 3 evaluation complete.")
    print(f"{'='*80}")


if __name__ == "__main__":
    main()
EOF
chmod +x scripts/evaluate_with_vs_without_image.py
```

Step 3.2: Run evaluation
─────────────────────────

```bash
python scripts/evaluate_with_vs_without_image.py 2>&1 | tee logs/step3_eval.log
```

This runs interactively (5-15 min). Output goes to stdout AND logs/step3_eval.log.

Step 3.3: Verify outputs generated
───────────────────────────────────

```bash
ls -la figure*.png d_hat_comparison.csv bootstrap_g3_ci.csv 2>/dev/null
```

Expected files:
  ✓ figure1_trajectories.png
  ✓ figure2_dhat_scatter.png
  ✓ figure3_ordering_heatmap.png
  ✓ d_hat_comparison.csv
  ✓ bootstrap_g3_ci.csv

================================================================================
SECTION 5: FAILURE MODES + RECOVERY
================================================================================

5.1 R packages install fail
─────────────────────────────
Try: module load conda_R
Or: contact bithelp@lists.jh.edu

5.2 test0822.cpp compilation fail
──────────────────────────────────
Try: module load gcc-9; module load r-rcpp; module load r-rcppeigen
Or use test0125.cpp instead (nearly identical):
  Edit R scripts to source test0125.cpp instead

5.3 Step 1 verify fails (γ_3 diverges from init)
─────────────────────────────────────────────────
Likely: data format mismatch. Re-check wang_input_k10.csv first 10 cols 
are biomarker, cols 11-14 are covariate. Print cols and verify against 
ADNI_k10/theta.csv expected ordering.

5.4 Step 2 (k=20) doesn't converge in 24 hours
───────────────────────────────────────────────
Increase time: -t 48:00:00 (shared partition allows up to 7 days)
Or: reduce maxit in converge_k20.R from 400 → 200, accept noisier fit

5.5 Bootstrap iter mostly fail (>50% fail rate)
────────────────────────────────────────────────
Could be: insufficient memory. Increase --mem=24G in submit_bootstrap.sh
Could be: init values bad. Use main fit final theta as init for bootstrap.

5.6 All image PC γ_2 < 1 (flat sigmoid)
────────────────────────────────────────
This means image PCs didn't get strong ordering. Still proceed to Step 3, 
report as negative finding for that PC (consistent with paper Wang Section 6).

================================================================================
SECTION 6: FINAL CHECKLIST
================================================================================

After all stages complete, verify:

[ ] adni_k10_verify/result/*_theta.csv exists (Step 1 final)
[ ] adni_k20_main/result/*_theta.csv exists (Step 2 final)
[ ] bootstrap_output/iter_*/theta_final.csv (≥ 50 iters)
[ ] wang_input_k10.csv, wang_input_k20.csv generated
[ ] d_hat_comparison.csv with d_mod3, d_hat_k10, d_hat_k20
[ ] bootstrap_g3_ci.csv with 95% CI for all 20 biomarker
[ ] figure1_trajectories.png
[ ] figure2_dhat_scatter.png
[ ] figure3_ordering_heatmap.png
[ ] logs/step1_*.out, logs/step2_*.out, logs/bs_*.out for review

Print final summary:
  - Step 1 status (pass/fail, iterations)
  - Step 2 status (pass/fail, iterations, image PC γ_2 health)
  - Bootstrap status (success rate)
  - Step 3 key numbers (Pearson k=20 vs k=10, CN/AD AUC delta)

Then STOP and tell user "Pipeline complete, review final summary above + figures."

================================================================================
END OF PROMPT — Run this entire pipeline autonomously. Submit SLURM jobs as 
listed. Don't ask user for confirmation between stages. Only stop if a 
PASS criterion explicitly fails and you can't recover.
================================================================================

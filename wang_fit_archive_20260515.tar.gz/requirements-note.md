# Runtime Notes

The JHPCE R environment used for these runs was:

```bash
module load R/4.3
export R_LIBS_USER=/dcs07/zwang/data/adni_d/wang_fit/R_libs
```

The local `R_libs/` directory is not committed. Reinstall the required packages in a fresh environment if needed:

- common
- logr
- FLasher and dependencies

The Python build scripts were run with:

```bash
source /users/szhang1/fsl/bin/activate optuna_env
```


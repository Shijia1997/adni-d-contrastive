# other functions
sigmod <- function(x, gamma){
  if (fun_type=='sigmoid'){
    return(gamma[1]/(1+exp(-(10*inv.logit(gamma[2])) * (x - gamma[3]))))
  } else if (fun_type=='richards'){
    return(gamma[1]/(1 + exp(-(10*inv.logit(gamma[2])) * (x - gamma[3]))/gamma[4])^gamma[4])
  } else if (fun_type=='piecewise'){
    indicator <- as.numeric(x <= gamma[3])
    return(indicator*(2*gamma[4]/(1 + exp(-(10*inv.logit(gamma[2])) * (x - gamma[3])))) + (1-indicator) * (2*gamma[4]-gamma[1]+2*(gamma[1]-gamma[4])/(1 + exp(-gamma[4]*(10*inv.logit(gamma[2])) * (x - gamma[3])/(gamma[1]-gamma[4])))))
  } else if (fun_type=='richards11'|| fun_type=='richards12'){
    return(gamma[1]/(1 + exp(-(10*inv.logit(gamma[2])) * (x - gamma[3]))/(10*inv.logit(gamma[4])))^(10*inv.logit(gamma[4])))
  } else if (fun_type=='piecewise11'|| fun_type=='piecewise12'){
    indicator <- as.numeric(x <= gamma[3])
    return(indicator*(2*(gamma[1]*inv.logit(gamma[4]))/(1 + exp(-(10*inv.logit(gamma[2])) * (x - gamma[3])))) + (1-indicator) * (2*(gamma[1]*inv.logit(gamma[4]))-gamma[1]+2*(gamma[1]-(gamma[1]*inv.logit(gamma[4])))/(1 + exp(-(gamma[1]*inv.logit(gamma[4]))*(10*inv.logit(gamma[2])) * (x - gamma[3])/(gamma[1]-(gamma[1]*inv.logit(gamma[4])))))))
  } else if (fun_type=='piecewise21'|| fun_type=='piecewise22') {
    indicator <- as.numeric(x <= gamma[3])
    return(indicator*(2*(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4]))/(1 + exp(-(10*inv.logit(gamma[2])) * (x - gamma[3])))) + (1-indicator) * (2*(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4]))-gamma[1]+2*(gamma[1]-(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4])))/(1 + exp(-(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4]))*(10*inv.logit(gamma[2])) * (x - gamma[3])/(gamma[1]-(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4])))))))
  } else {
    stop('no such function type.')
  }
}


### generate d
trans.fun <- function(alphaz, gamma, error.delta, fun_type){
  if (fun_type=='sigmoid'){
    return(gamma[1]/(1 + exp(-(10*inv.logit(gamma[2])) * (alphaz + error.delta - gamma[3]))))
  } else if (fun_type=='richards'){
    return(gamma[1]/(1 + exp(-(10*inv.logit(gamma[2])) * (alphaz + error.delta - gamma[3]))/gamma[4])^gamma[4])
  } else if (fun_type=='piecewise'){
    if (alphaz + error.delta <= gamma[3]){ 
      return(2*gamma[4]/(1 + exp(-(10*inv.logit(gamma[2])) * (alphaz + error.delta - gamma[3])))) 
    } 
    else { 
      return(2*gamma[4]-gamma[1]+2*(gamma[1]-gamma[4])/(1 + exp(-gamma[4]*(10*inv.logit(gamma[2])) * (alphaz + error.delta - gamma[3])/(gamma[1]-gamma[4])))) 
    } 
  } else if (fun_type == 'richards11' || fun_type == 'richards12') {
    return (gamma[1]/(1 + exp(-(10*inv.logit(gamma[2])) * (alphaz + error.delta - gamma[3]))/(10*inv.logit(gamma[4])))^(10*inv.logit(gamma[4])))
  } else if  (fun_type == 'piecewise11' || fun_type == 'piecewise12') {
    if (alphaz + error.delta <= gamma[3]){ 
      return(2*(gamma[1]*inv.logit(gamma[4]))/(1 + exp(-(10*inv.logit(gamma[2])) * (alphaz + error.delta - gamma[3])))) 
    } 
    else { 
      return(2*(gamma[1]*inv.logit(gamma[4]))-gamma[1]+2*(gamma[1]-(gamma[1]*inv.logit(gamma[4])))/(1 + exp(-(gamma[1]*inv.logit(gamma[4]))*(10*inv.logit(gamma[2])) * (alphaz + error.delta - gamma[3])/(gamma[1]-(gamma[1]*inv.logit(gamma[4])))))) 
    } 
  } else if  (fun_type == 'piecewise21'|| fun_type == 'piecewise22') {
    if (alphaz + error.delta <= gamma[3]){ 
      return(2*(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4]))/(1 + exp(-(10*inv.logit(gamma[2])) * (alphaz + error.delta - gamma[3])))) 
    } 
    else { 
      return(2*(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4]))-gamma[1]+2*(gamma[1]-(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4])))/(1 + exp(-(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4]))*(10*inv.logit(gamma[2])) * (alphaz + error.delta - gamma[3])/(gamma[1]-(0.1*gamma[1]+0.8*gamma[1]*inv.logit(gamma[4])))))) 
    } 
  } else {
    stop('no such function type.')
  }
}

### generate y
fun.mu <- function(beta, gamma, alpha, x, z, error.delta, j, fun_type) {
  mu <- matrix(0, nrow = j, ncol = k)
  xbeta <- matrix(unlist(beta), nr = k, byrow = T) %*% x
  for (kk in 1:k) {
    mu[, kk] <- trans.fun((z %*% alpha), gamma[[kk]], error.delta, fun_type)
  }
  mu <- sweep(mu, 2, xbeta, "+")
  return(mu)
}



nlme_gqnr <- function(x, y, z, IDs, phi0, theta0, cor0, cov_str, gq_nodes, p_weight, w4,theta0_fixed, cor0_fixed, maxit, fun_type, path, output_path, lp, opt='NR') {
  log_file <- file.path(paste(path, output_path, sep = ""), paste(lp, ".log",sep = ""))
  lf <- log_open(log_file)
  
  log_print('theta0: ')
  log_print(theta0)
  log_print('phi0: ')
  log_print(phi0)
  log_print('cor0: ')
  log_print(cor0)
  
  k <- nrow(theta0_fixed)
  p <- ncol(x)
  gamma_num <- ncol(theta0_fixed) - p - 1
  q <- ncol(z)
  y1 <- y
  x1 <- x
  z1 <- z
  dm <- dim(y1)
  
  ## create a missing data indicator matrix: # of observed markers and marker index at each visit
  na.mat <- matrix(rep(0:(dm[2] - 1), dm[1]), nrow = dm[1], ncol = dm[2], byrow = T)
  na.mat[which(is.na(y1))] <- NA
  ind <- cbind(apply(!is.na(y1), 1, sum), t(apply(na.mat, 1, function(x) sort(x, na.last=T))))
  
  ## calculate nodes and weights for Gaussian quadrature
  nodes <- gq_nodes
  gq <- gauss.quad(nodes,kind="hermite")
  es <- sqrt(2) * matrix(gq$nodes)
  weight <- matrix(gq$weights)
  phi0 <- phi0
  theta0 <- c(as.vector(theta0),
              as.vector(cor0))
  
  
  ## create the variance-covariance matrix of markers
  cov_list <- cov_str
  cov_list[,-1] <- cov_list[,-1] - 1
  
  n_cov <- nrow(cov_list)
  covmat_temp <- matrix(NA,nrow = k, k)
  cov_list_temp <- matrix(cov_list[,-1],nrow = n_cov)+1
  count <- 1
  for (i in 1:nrow(cov_list)) {
    for (j in 1:cov_list[i,1]) {
      covmat_temp[cov_list_temp[i,2*j-1],cov_list_temp[i,2*j]] <- count
    }
    count <- count + 1
  }
  
  
  
  ## cov_pos[[i]]: a matrix specifies the structure of covariance matrix for the i-th visit
  ## The first column of the matrix represents correlation coefficients index
  ## The second column of the matrix represents the number of occurrences of the parameter in the upper triangular portion of the covariance matrix. 
  ## The subsequent columns denote the horizontal and vertical positions of the parameter in the upper triangular portion of the covariance matrix. 
  ind_temp <- ind[,-1]
  ind_temp <- ind_temp+1
  
  cov_pos <- list()
  for (i in 1:nrow(ind)) {
    pos_temp <- !is.na(ind_temp[i,])
    ct1 <- covmat_temp[ind_temp[i,pos_temp],ind_temp[i,pos_temp]]
    t1 <- NULL
    for (j in 1:nrow(cov_list)) {
      temp <- matrix(t(which(ct1==j, arr.ind = T)),nrow = 1)
      if (length(temp)==0)
        next()
      np <-ncol(temp)/2
      length(temp) <- ncol(cov_list_temp)
      t1 <- rbind(t1, c(j,np,temp-1))
    }
    cov_pos[[i]] <- t1
  }
  
  
  
  ## hess_fd[i, ]: a vector of available paramter index for the i-th visit. A complete paramter index (without missing values) is c(as.vector(theta0), phi0, cor0).
  hess_fd <- NULL
  for (i in 1:nrow(ind)) {
    hess_ind <- 1:(k*p+(gamma_num+1)*k)
    k_ind <- 1:k
    k_temp <- k_ind[which(!(k_ind %in% ind_temp[i,]))]
    if (length(k_temp)==0){
      
    } else {
      for (j in 1:length(k_temp)) {
        hess_ind[seq(1,k*p+(gamma_num+1)*k,k)+k_temp[j]-1] <- NA
      }
    }
    hess_d2 <- cov_pos[[i]][,1] + (k*p+(gamma_num+1)*k)
    length(hess_d2) <- nrow(cov_list_temp)
    hess_fd <- rbind(hess_fd, sort(c(hess_ind, hess_d2),decreasing = F,na.last = T))
  }
  
  w <- p_weight
  
  
  theta0_fixed <- as.vector(theta0_fixed)
  cor0_fixed <- as.vector(cor0_fixed)
  fix_pos <- c(which(theta0_fixed == 1), k*(p+gamma_num+1) + which(cor0_fixed == 1))
  
  loss_list <- c()
  convergence_list <- c()
  neg_likelihood_list <- c()
  g_norm_list <- c()
  h_emin_list <- c()
  
  
  ## the Newton-Raphson method
  tryCatch({
    for (a in 1:maxit) {
      log_print('---------------------------------------------')

      para_old <- c(theta0, phi0)
      para_new_list <- newton_iter(theta0=theta0, phi0=phi0, x1=x1, y1=y1, z1=z1,
                                    es=es, weight=weight, ind=ind, cov_list=cov_list,
                                    cov_pos=cov_pos, hess_fd=hess_fd, nodes=nodes, w=w, w4=w4,
                                    fix_pos=fix_pos, gamma_num=gamma_num, fun_type=fun_type, opt=opt)
      theta0 <- para_new_list[[1]]
      phi0 <- para_new_list[[2]]
      neg_likelihood <- para_new_list[[3]]
      g_norm <- para_new_list[[4]]
      h_emin <- para_new_list[[5]]
      loglik_deriv <- para_new_list[[6]]

      para_new <- c(theta0, phi0)

      err <- max(abs(para_old-para_new)/(abs(para_old)+0.001))
      ## calculate sse
      theta0_main <- theta0[1:(k*(p+gamma_num+1))]
      theta0_mat <- matrix(theta0_main,nrow = k)
      x <- x1
      betax <- as.matrix(x) %*% t(theta0_mat[,1:p])
      y <- y1
      err_mat <- y-betax
      err_temp <- err_mat
      alphaz <- as.matrix(z1, ncol = q) %*% matrix(phi0,ncol = 1)
      alphaz <- do.call("cbind", rep(list(alphaz), nodes))
      alphazerr <- sweep(alphaz, 2, t(es), '+')

      trans_d <- list()
      for (i in 1:k) {
        gamma_tmp <- as.numeric(theta0_mat[i,(p+1):(p+gamma_num)])
        trans_d[[i]] <- sigmod(x = alphazerr, gamma = gamma_tmp)
        err_mat[,i] <- err_mat[,i]-(trans_d[[i]] %*% weight)/sqrt(pi)
      }
      sse <- sum(err_mat^2,na.rm = T)

      log_print('g_norm')
      log_print(g_norm)
      log_print('h_emin')
      log_print(h_emin)

      log_print("Iteration:")
      log_print(a)
      log_print("theta:")
      log_print(matrix(theta0[1:(k*(p + gamma_num + 1))], nrow = k, ncol = p + gamma_num + 1))
      log_print("correlation:")
      log_print(matrix(theta0[(k*(p + gamma_num + 1) + 1):length(theta0)], nrow = 1))
      log_print("phi:")
      log_print(phi0)
      log_print("convergence criterion:")
      log_print(err)
      log_print('loss')
      log_print(sse)
      loss_list <- c(loss_list, sse)
      convergence_list <- c(convergence_list, err)

      log_print('neg_likelihood')
      log_print(neg_likelihood)
      neg_likelihood_list <- c(neg_likelihood_list, neg_likelihood)
      g_norm_list <- c(g_norm_list, g_norm)
      h_emin_list <- c(h_emin_list, h_emin)
      if (stop_criterion(g_norm,err)){
        break
      }

      output_temp <- list()
      output_temp[["theta"]] <- matrix(theta0[1:(k*(p + 4))], nrow = k, ncol = p + 4)
      colnames(output_temp[["theta"]]) <- c(paste0("beta_",1:p, sep = ""), paste0("gamma_",1:3, sep = ""), "sigma")
      output_temp[["cor"]] <- matrix(theta0[(k*(p + 4) + 1):length(theta0)], nrow = 1)
      output_temp[["phi"]] <- phi0
      output_temp[["convergence criteria"]] <- err
      output_temp[["log_likelihood"]] <- nlme_loglikeli(theta0 = theta0, x0 = x, y0 = y[,1:k],z0 = z,alpha0 = phi0, err0 = es,weight0 = weight,ind = ind, gp_ind = cov_list, gamma_num=gamma_num, fun_type=fun_type_num(fun_type))

    }



    ## louis formula
    w <- 0
    
    A_mat <- hess1 <- hess2 <- hess3 <- matrix(0,nrow = length(theta0)+q,ncol = length(theta0)+q)
    
    IDs_uni <- unique(IDs)
    for( num in 1:length(IDs_uni)){
      pos <- which(IDs == IDs_uni[num])
      grad <- matrix(0,nrow = length(theta0)+q,ncol = 1)
      
      for (sub in 1:length(pos)) {
        sub_id <- pos[sub]
        sec <- matrix(0,nrow = length(theta0)+q,ncol = 1)
        theta_m <- matrix(theta0[1:(k*(p+gamma_num+1))],nrow = k,ncol = p+gamma_num+1,byrow = F)
        id_save <- ind[sub_id,2:(ind[sub_id,1]+1)]+1
        theta_m <- as.numeric(theta_m[id_save,])
        
        if(length(cov_pos[[sub_id]])!=0) {
          gpidsave <- c(cov_pos[[sub_id]][,1])
          theta_m <- c(theta_m, theta0[k*(p+gamma_num+1)+ gpidsave])
        }
        id_na <- hess_fd[sub_id,!is.na(hess_fd[sub_id,])]
      
        if (length(cov_pos[[sub_id]])==0) {
          true_pos <- matrix(0)
        } else {
          true_pos <- cov_pos[[sub_id]]
        }
      
        for (nd in 1:nodes) {
          qes <- matrix(0,nrow = length(theta0)+q,ncol = 1)
          cv <- louis_gau(theta0 = theta0,x0 = x1, y0 = y1[,1:k],z0 = z1,alpha0 = phi0, err0 = es, weight0 = weight,
                        ind =ind,gp_ind = cov_list,num = sub_id-1, nd=nd-1, gamma_num=gamma_num, fun_type=fun_type_num(fun_type))
          phi0_temp <- cv[[3]]
          temp2_g <- phi0_temp[1:q]
          temp2_h <- matrix(data = phi0_temp[(q+1):(q+q^2)],nrow = q,ncol = q)
          d_temp <- cv[[2]]
          wet <- cv[[1]]
          theta_bt <- theta_deriv_temp(theta0 = theta_m,
                                     x0 = matrix(x1[sub_id,],nrow = 1),
                                     alphaz0 = matrix(d_temp[nd]),
                                     y0 = matrix(y1[sub_id,id_save],nrow = 1),cov_mat = true_pos, gamma_num=gamma_num, fun_type=fun_type_num(fun_type))
          sec[id_na,] <- sec[id_na,] + theta_bt[[1]]*wet[nd]
          sec[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),] <- sec[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),] + temp2_g*wet[nd]
          hess1[id_na,id_na] <- hess1[id_na,id_na] + theta_bt[[2]]*wet[nd]
          hess1[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),(1:q)+(k*(p+gamma_num+1)+nrow(cov_list))] <- hess1[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),(1:q)+(k*(p+gamma_num+1)+nrow(cov_list))] + temp2_h*wet[nd]
          qes[id_na,] <- theta_bt[[1]]
          qes[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),] <-  temp2_g
          hess2 <- hess2 + wet[nd]*(qes %*% t(qes))
          
          
        }
        hess3 <- hess3 + sec %*% t(sec)
      }
      A_mat <- A_mat + grad %*% t(grad)
    }
    
    
    
    hess <- -hess1 - hess2 + hess3
    if (length(fix_pos) != 0) {
      hess <- hess[-fix_pos, ]
      hess <- hess[, -fix_pos]
    }
    
    
    ## calculate sse
    theta0_main <- theta0[1:(k*(p+gamma_num+1))]
    theta0_mat <- matrix(theta0_main,nrow = k)
    x <- x1
    betax <- as.matrix(x) %*% t(theta0_mat[,1:p])
    y <- y1
    err_mat <- y-betax
    err_temp <- err_mat
    alphaz <- as.matrix(z1, ncol = q) %*% matrix(phi0,ncol = 1)
    alphaz <- do.call("cbind", rep(list(alphaz), nodes))
    alphazerr <- sweep(alphaz, 2, t(es), '+')
    
    trans_d <- list()
    for (i in 1:k) {
      gamma_tmp <- as.numeric(theta0_mat[i,(p+1):(p+gamma_num)])
      trans_d[[i]] <- sigmod(x = alphazerr, gamma = gamma_tmp)
      err_mat[,i] <- err_mat[,i]-(trans_d[[i]] %*% weight)/sqrt(pi)
    }
    sse <- sum(err_mat^2,na.rm = T)
    
    

    
    output <- list()
    output[["theta"]] <- matrix(theta0[1:(k*(p + gamma_num + 1))], nrow = k, ncol = p + gamma_num + 1)
    colnames(output[["theta"]]) <- c(paste0("beta_",1:p, sep = ""), paste0("gamma_",1:gamma_num, sep = ""), "sigma")
    output[["cor"]] <- matrix(theta0[(k*(p + gamma_num + 1) + 1):length(theta0)], nrow = 1)
    output[["phi"]] <- phi0
    output[["convergence criteria"]] <- err
    output[["inf_mat"]] <- hess
    output[["sse"]] <- sse
    
    output[["log_likelihood"]] <- nlme_loglikeli(theta0 = theta0, x0 = x1, y0 = y1[,1:k],z0 = z1,alpha0 = phi0, err0 = es,weight0 = weight,ind = ind, gp_ind = cov_list,gamma_num=gamma_num, fun_type=fun_type_num(fun_type))
    output[["loss_list"]] <- loss_list
    output[["convergence_list"]] <- convergence_list
    output[["loglik_deriv"]] <- loglik_deriv
    output[["g_norm_list"]] <- g_norm_list
    output[["A_mat"]] <- A_mat
    output[["neg_likelihood_list"]] <- neg_likelihood_list
#       ## calculate sse_test
#       theta0_main <- theta0[1:(k*(p+gamma_num+1))]
#       theta0_mat <- matrix(theta0_main,nrow = k)
#       x <- x_test
#       betax <- as.matrix(x_test) %*% t(theta0_mat[,1:p])
#       y <- y_test
#       err_mat <- y_test-betax
#       err_temp <- err_mat
#       alphaz <- as.matrix(z_test, ncol = q) %*% matrix(phi0,ncol = 1)
#       alphaz <- do.call("cbind", rep(list(alphaz), nodes))
#       alphazerr <- sweep(alphaz, 2, t(es), '+')
#       
#       trans_d <- list()
#       for (i in 1:k) {
#         gamma_tmp <- as.numeric(theta0_mat[i,(p+1):(p+gamma_num)])
#         trans_d[[i]] <- sigmod(x = alphazerr, gamma = gamma_tmp)
#         err_mat[,i] <- err_mat[,i]-(trans_d[[i]] %*% weight)/sqrt(pi)
#       }
#       sse_test <- sum(err_mat^2,na.rm = T)
#       output[["sse_test"]] <- sse_test
    output[["lambda"]] <- p_weight
    output[["lambda2"]] <- w4
    save(output, file = paste(paste(path, output_path, sep = ""), "result/",lp,".RData",sep = ""))
    log_close()
    writeLines(readLines(lf))
  }, error = function(err.msg){
    write(toString(err.msg), paste(paste(path, output_path, sep = ""), "err/", lp, ".txt",sep = ""), append=TRUE)
  })
}


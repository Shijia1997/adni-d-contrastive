// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::depends(FLasher)]]
#include <FLasher.h>
#include <cppad/cppad.hpp>
#include <Rcpp.h>
#include <RcppEigen.h>
using namespace Rcpp;
using namespace Eigen;
using namespace std;
double inv_logit(double xx)
{
  return 1/(1+std::exp(-xx));
}

double eigen_exp(double xx)
{
  return std::exp(xx);
}

void removeColumn(Eigen::MatrixXd& matrix, unsigned int colToRemove)
{
  unsigned int numRows = matrix.rows();
  unsigned int numCols = matrix.cols()-1;

  if( colToRemove < numCols )
    matrix.block(0,colToRemove,numRows,numCols-colToRemove) = matrix.block(0,colToRemove+1,numRows,numCols-colToRemove);

  matrix.conservativeResize(numRows,numCols);
}


void removeRow(Eigen::MatrixXd& matrix, unsigned int rowToRemove)
{
  unsigned int numRows = matrix.rows()-1;
  unsigned int numCols = matrix.cols();

  if( rowToRemove < numRows )
    matrix.block(rowToRemove,0,numRows-rowToRemove,numCols) = matrix.block(rowToRemove+1,0,numRows-rowToRemove,numCols);

  matrix.conservativeResize(numRows,numCols);
}

Eigen::MatrixXd MH_cal(Eigen::MatrixXd x1, Eigen::MatrixXd y1, Eigen::MatrixXd z1,
                       size_t k, size_t p, size_t nr, Eigen::VectorXd theta, Eigen::MatrixXd beta,
                       Eigen::MatrixXd gamma, Eigen::VectorXd alpha, Eigen::MatrixXd err, Eigen::MatrixXd sigma_mat, Eigen::MatrixXi ind, size_t fun_type) {
  size_t j=0, i, I_c;
  Eigen::MatrixXd alphaz, betax, mu, output, mu_m;

  // Parameter Initialization
  mu = Eigen::MatrixXd::Zero(nr, k);
  output = Eigen::MatrixXd::Zero(nr, 1);
  betax = (beta*x1.transpose()).transpose().replicate(nr, 1);
  alphaz = (z1*alpha).transpose().replicate(nr,1) + err;
  // alphaz = alphaz.unaryExpr(&inv_logit);

  for (size_t kk = 0; kk < k; kk++){
    for (size_t n = 0; n < nr; n++){
      // mu(n, kk)=gamma(kk, 0)/(1 + std::exp(-(40*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - inv_logit(gamma(kk, 2)))));
      if (fun_type == 0) {
      mu(n, kk)=gamma(kk, 0)/(1 + std::exp(-(10*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - gamma(kk, 2))));
      } else if (fun_type == 1) {
      mu(n, kk)=gamma(kk, 0)/pow(1 + std::exp(-(10*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - gamma(kk, 2)))/gamma(kk, 3), gamma(kk, 3)); 
      } else if (fun_type == 2) {
      if (alphaz(n, j) < gamma(kk, 2)){
        mu(n, kk)=2*gamma(kk,3)/(1 + std::exp(-(10*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - gamma(kk, 2))));          
      }else{
        mu(n, kk)=2*gamma(kk,3)-gamma(kk,0)+2*(gamma(kk, 0)-gamma(kk, 3))/(1 + std::exp(-gamma(kk,3)*(10*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - gamma(kk, 2))/(gamma(kk,0)-gamma(kk,3))));  
      }  
      } else if (fun_type == 3){
        mu(n, kk)=gamma(kk, 0)/pow(1 + std::exp(-(10*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - gamma(kk, 2)))/(10*inv_logit(gamma(kk, 3))), (10*inv_logit(gamma(kk, 3))));
      } else if (fun_type == 4){
        if (alphaz(n, j) < gamma(kk, 2)){
          mu(n, kk)=2*(gamma(kk,0)*inv_logit(gamma(kk,3)))/(1 + std::exp(-(10*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - gamma(kk, 2))));          
        }else{
          mu(n, kk)=2*(gamma(kk,0)*inv_logit(gamma(kk,3)))-gamma(kk,0)+2*(gamma(kk, 0)-(gamma(kk,0)*inv_logit(gamma(kk,3))))/(1 + std::exp(-(gamma(kk,0)*inv_logit(gamma(kk,3)))*(10*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - gamma(kk, 2))/(gamma(kk,0)-(gamma(kk,0)*inv_logit(gamma(kk,3))))));  
        }  
      } else if (fun_type == 5){
        if (alphaz(n, j) < gamma(kk, 2)){
          mu(n, kk)=2*(0.1*gamma(kk,0)+0.8*gamma(kk,0)*inv_logit(gamma(kk,3)))/(1 + std::exp(-(10*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - gamma(kk, 2))));          
        }else{
          mu(n, kk)=2*(0.1*gamma(kk,0)+0.8*gamma(kk,0)*inv_logit(gamma(kk,3)))-gamma(kk,0)+2*(gamma(kk, 0)-(0.1*gamma(kk,0)+0.8*gamma(kk,0)*inv_logit(gamma(kk,3))))/(1 + std::exp(-(0.1*gamma(kk,0)+0.8*gamma(kk,0)*inv_logit(gamma(kk,3)))*(10*inv_logit(gamma(kk, 1)))*(alphaz(n, j) - gamma(kk, 2))/(gamma(kk,0)-(0.1*gamma(kk,0)+0.8*gamma(kk,0)*inv_logit(gamma(kk,3))))));  
        }  
      } else {
        
      }
      // mu(n, kk)=gamma(kk, 0)/(1 + std::exp(-gamma(kk, 1)*(alphaz(n, j) - gamma(kk, 2))));
      // mu(n, kk)=gamma(kk, 0)/(1 + std::exp(-gamma(kk, 1)*(alphaz(n, j) - inv_logit(gamma(kk, 2)))));
    }
  }
  mu = y1.row(j).replicate(nr, 1) - betax - mu;
  mu_m = Eigen::MatrixXd::Zero(nr, ind(0, 0));
  I_c = ind(0, 0);
  for (i = 0; i < I_c; i++)
    mu_m.col(i) = mu .col(ind(0, i+1));
  // output = (mu * sigma_mat.inverse()).cwiseProduct(mu).rowwise().sum() ;
  output = (mu_m * sigma_mat.inverse()).cwiseProduct(mu_m).rowwise().sum() ;
  return -0.5*output;
}


std::vector<double> phi_deriv2(std::vector<double> phi0, Eigen::MatrixXd z0, Eigen::MatrixXd alphaz0, size_t wu) {
  using CppAD::AD;
  using Eigen::Matrix;
  using Eigen::Dynamic;
  typedef Matrix< AD<double> , Dynamic, Dynamic > a_matrix;
  typedef Matrix< AD<double> , Dynamic , 1>       a_vector;

  // Parameter Initialization
  size_t i, j_time = 1, phi_len = phi0.size();
  a_vector alphaz(j_time),  likelihood(1), phi(phi_len);
  a_matrix sigma_mat(j_time, j_time), z(j_time, phi_len);
  alphaz[0] = alphaz0(wu,0);
  for(i = 0; i < (phi_len); i++) {
    z(0, i) = z0(i, 0);
  }
  Map<a_matrix> alpha(phi.block(0, 0, phi_len, 1).data(), phi_len, 1);
  CppAD::Independent(phi);
  sigma_mat = a_matrix::Ones(1 , 1);
  alphaz -= z*alpha;

  // compute gradient/hessian of log likelihood
  likelihood[0] =-0.5*log(sigma_mat.determinant())+(-0.5*alphaz.transpose()*sigma_mat.inverse()*alphaz)(0);
  CppAD::ADFun<double> f(phi, likelihood);

  std::vector<double> jac = f.Jacobian(phi0);
  std::vector<double> hes = f.Hessian(phi0, 0);
  std::vector<double> AB;
  AB.reserve( jac.size() + hes.size() ); // preallocate memory
  AB.insert( AB.end(), jac.begin(), jac.end() );
  AB.insert( AB.end(), hes.begin(), hes.end() );
  // List L = List::create(jac, hes);
  return AB;
}

//std::vector<double> phi_deriv2_fast(std::vector<double> phi0, Eigen::MatrixXd z0, Eigen::MatrixXd alphaz0, size_t wu) { // K: add the function phi_deriv2_fast
  
//  size_t phi_len = phi0.size();
//  double d = alphaz0(wu,0);
//  Eigen::MatrixXd d_vector(phi_len,1);
//  d_vector.fill(d);
//  Eigen::VectorXd alpha0(phi0.data());
//  Eigen::MatrixXd delta_mean = d_vector - z0*alpha0;
//  Eigen::MatrixXd jac=delta_mean * z0; // K:add
  
//  Eigen::MatrixXd hes=-z0*z0.transpose();
  
//  std::vector<double> jac_vector(jac.data(), jac.data() + jac.size());
//  std::vector<double> hes_vector(hes.data(), hes.data() + hes.size());
  
//  std::vector<double> AB; 
//  AB.reserve( jac_vector.size() + hes_vector.size() ); 
//  AB.insert( AB.end(), jac_vector.begin(), jac_vector.end() ); 
//  AB.insert( AB.end(), hes_vector.begin(), hes_vector.end() ); 
//  return AB;
//}

// [[Rcpp::export]]
Eigen::MatrixXd nlme_loglikeli(NumericVector theta0, NumericMatrix x0, NumericMatrix y0,
                               NumericMatrix z0, NumericVector alpha0, NumericMatrix err0, NumericMatrix weight0, Eigen::MatrixXi ind, Eigen::MatrixXi gp_ind, size_t gamma_num, size_t fun_type) {
  size_t k = y0.ncol(), p = x0.ncol(), nr = err0.nrow(), i,j, num_all = y0.nrow(), tm, e,f,g;
  int K = k, P=p, gp=gp_ind.rows();
  MatrixXd oct, mat_det, temp, results, likelihood, theta_mat;
  likelihood = Eigen::MatrixXd::Zero(1, 1);
  std::vector<double> out2, out1;
  // Parameter Initialization
  Map<Eigen::VectorXd> theta(Rcpp::as<Eigen::Map<Eigen::VectorXd> >(theta0));
  Map<Eigen::MatrixXd> beta(theta.block(0, 0, k * p, 1).data(), k, p);
  Map<Eigen::MatrixXd> gamma(theta.block(k*p, 0, gamma_num * k, 1).data(), k, gamma_num);
  Map<Eigen::VectorXd> alpha(Rcpp::as<Eigen::Map<Eigen::VectorXd> >(alpha0));
  Map<Eigen::MatrixXd> err(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(err0));
  Map<Eigen::MatrixXd> weights(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(weight0));
  Map<Eigen::MatrixXd> x(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(x0));
  Map<Eigen::MatrixXd> z(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(z0));
  Map<Eigen::MatrixXd> y(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(y0));
  Map<Eigen::MatrixXd> theta_tempt(theta.data(), K, P +gamma_num+1);
  theta_mat = theta_tempt;
  std::vector<double> phi0 = as<std::vector<double> >(alpha0);
  Eigen::MatrixXd sigma_mat, sigma_m;
  sigma_mat = Eigen::MatrixXd::Zero(k, k);
  for(i = 0; i < k; i++) {
    sigma_mat(i, i) = pow(theta[k*p + 3*k + i], 2);
  }

  for(i = 0; i < gp; i++) {
    for (j = 0; j < gp_ind(i,0); j++) {
      sigma_mat(gp_ind(i,2*j+1),gp_ind(i,2*j+2)) = theta[k*p + gamma_num*k + k + i]*theta[k*p + gamma_num*k + gp_ind(i,2*j+1)]*theta[k*p + gamma_num*k + gp_ind(i,2*j+2)];
      sigma_mat(gp_ind(i,2*j+2),gp_ind(i,2*j+1)) = theta[k*p + gamma_num*k + k + i]*theta[k*p + gamma_num*k + gp_ind(i,2*j+1)]*theta[k*p + gamma_num*k + gp_ind(i,2*j+2)];
    }
  }

  for(size_t num = 0; num < num_all; num++) {
    mat_det = Eigen::MatrixXd::Ones(nr, 1);
    g = ind(num, 0);
    sigma_m = Eigen::MatrixXd::Zero(g, g);
    for(i = 0; i < g; i++) {
      e = ind(num, i+1);
      for (tm = 0; tm < g; tm++) {
        f = ind(num, tm+1);
        sigma_m(i, tm) = sigma_mat(e, f);
      }
    }
    mat_det *= (log(pow(2*M_PI, -.5*ind(0, 0))) +  -0.5*log(sigma_m.determinant()));
    oct = MH_cal(x.row(num), y.row(num), z.row(num), k, p, nr, theta, beta, gamma, alpha, err, sigma_m, ind.row(num), fun_type);
    results = mat_det + oct;
    // results = results.array() - results.maxCoeff();
    results =  results.unaryExpr(&eigen_exp);
    likelihood(0, 0) = likelihood(0, 0) + log((results.transpose()*weights/1.772454)(0));
  }



  return likelihood;
}


// [[Rcpp::export]]
List gau(NumericVector theta0, NumericMatrix x0, NumericMatrix y0,
         NumericMatrix z0, NumericVector alpha0, NumericMatrix err0,
         NumericMatrix weight0, Eigen::MatrixXi ind, Eigen::MatrixXi gp_ind, size_t num, size_t gamma_num, size_t fun_type) {
  size_t k = y0.ncol(), p = x0.ncol(), nr = err0.nrow(), i,j, num_all = y0.nrow(), q=z0.ncol(), kk, k3, tm, e,f,g,count = 0;
  int K = k, P=p, Q=q, gp=gp_ind.rows();
  MatrixXd oct, mat_det, temp2, temp1, temp, results, mat_freq, theta_mat,theta_grad_temp,theta_grad,theta_hess_temp,theta_hess;
  // temp1 = Eigen::MatrixXd::Zero(pow(P + 4, 2) + P +4, K);
  temp2 = Eigen::MatrixXd::Zero(pow(Q, 2) + Q, 1);
  theta_grad = Eigen::MatrixXd::Zero(K*(P+gamma_num+1) + gp,1);
  theta_hess = Eigen::MatrixXd::Zero(K*(P+gamma_num+1) + gp, K*(P+gamma_num+1) + gp);
  std::vector<double> out2, out1;
  // Parameter Initialization
  Map<Eigen::VectorXd> theta(Rcpp::as<Eigen::Map<Eigen::VectorXd> >(theta0));
  Map<Eigen::MatrixXd> beta(theta.block(0, 0, k * p, 1).data(), k, p);
  Map<Eigen::MatrixXd> gamma(theta.block(k*p, 0, gamma_num * k, 1).data(), k, gamma_num);
  Map<Eigen::VectorXd> alpha(Rcpp::as<Eigen::Map<Eigen::VectorXd> >(alpha0));
  Map<Eigen::MatrixXd> err(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(err0));
  Map<Eigen::MatrixXd> weights(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(weight0));
  Map<Eigen::MatrixXd> x(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(x0));
  Map<Eigen::MatrixXd> z(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(z0));
  Map<Eigen::MatrixXd> y(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(y0));
  Map<Eigen::MatrixXd> theta_tempt(theta.data(), K, P + gamma_num + 1);
  theta_mat = theta_tempt;
  std::vector<double> phi0 = as<std::vector<double> >(alpha0);
  std::vector<double> theta11 = as<std::vector<double> >(theta0);
  Eigen::MatrixXd sigma_mat, sigma_m;
  sigma_mat = Eigen::MatrixXd::Zero(k, k);
  for(i = 0; i < k; i++) {
    sigma_mat(i, i) = pow(theta[k*p + gamma_num*k + i], 2);
  }


  for(i = 0; i < gp; i++) {
    for (j = 0; j < gp_ind(i,0); j++) {
      sigma_mat(gp_ind(i,2*j+1),gp_ind(i,2*j+2)) = theta[k*p + gamma_num*k + k + i]*theta[k*p + gamma_num*k + gp_ind(i,2*j+1)]*theta[k*p + gamma_num*k + gp_ind(i,2*j+2)];
      sigma_mat(gp_ind(i,2*j+2),gp_ind(i,2*j+1)) = theta[k*p + gamma_num*k + k + i]*theta[k*p + gamma_num*k + gp_ind(i,2*j+1)]*theta[k*p + gamma_num*k + gp_ind(i,2*j+2)];
    }
  }



  // for(i = 0; i < k; i++) {
  //   for (j = i + 1; j < gp_ind[count]; j++) {
  //     sigma_mat(i, j) = theta[k*p + 3*k + k + count]*theta[k*p + 3*k + i]*theta[k*p + 3*k + j];
  //     sigma_mat(j, i) = theta[k*p + 3*k + k + count]*theta[k*p + 3*k + i]*theta[k*p + 3*k + j];
  //   }
  //   if (i == (gp_ind[count]-1)) {
  //     count +=1;
  //   }
  // }

  // for(size_t num = 0; num < num_all; num++) {
  mat_det = Eigen::MatrixXd::Ones(nr, 1);
  g = ind(num, 0);
  sigma_m = Eigen::MatrixXd::Zero(g, g);
  for(i = 0; i < g; i++) {
    e = ind(num, i+1);
    for (tm = 0; tm < g; tm++) {
      f = ind(num, tm+1);
      sigma_m(i, tm) = sigma_mat(e, f);
    }
  }
  mat_det *= (log(pow(2*M_PI, -.5*ind(0, 0))) +  -0.5*log(sigma_m.determinant()));
  oct = MH_cal(x.row(num), y.row(num), z.row(num), k, p, nr, theta, beta, gamma, alpha, err, sigma_m, ind.row(num), fun_type);
  results = mat_det + oct;
  results = results.array() - results.maxCoeff();
  results =  results.unaryExpr(&eigen_exp);
  mat_freq = results.array()*weights.array()/(results.transpose()*weights)(0);
  temp = (z.row(num)*alpha).transpose().replicate(nr,1) + err;
  for(i = 0; i < nr; i++) {
    out2 = phi_deriv2(phi0, z.row(num), temp, i);
    Map<MatrixXd> m2(out2.data(), pow(Q, 2) + Q, 1);
    temp2 = temp2 +  mat_freq(i,0) * m2;
  }
  List C = List::create(mat_freq,temp,temp2);
  return C;
}

// [[Rcpp::export]]
List theta_deriv_temp(std::vector<double> theta0, Eigen::MatrixXd x0, Eigen::MatrixXd alphaz0,
                      Eigen::MatrixXd y0, Eigen::MatrixXi cov_mat, size_t gamma_num, size_t fun_type) {
  using CppAD::AD;
  using Eigen::Matrix;
  using Eigen::Dynamic;
  typedef Matrix< AD<double> , Dynamic, Dynamic > a_matrix;
  typedef Matrix< AD<double> , Dynamic , 1>       a_vector;


  // Parameter Initializationet
  size_t i, j, k = y0.size(), p = x0.size(), theta_len = theta0.size(), count = 0;
  a_vector x(p), y(k),  likelihood(1), theta(theta_len), alphaz(1);
  a_matrix sigma_mat(k, k);



  alphaz[0] = alphaz0(0,0);
  for(i = 0; i < p; i++)
    x[i] = x0(0, i);
  for(i = 0; i < k; i++)
    y[i] = y0(0, i);

  for(i = 0; i < theta_len; i++)
    theta[i] = theta0[i];


  Map<a_matrix> beta(theta.block(0, 0, k * p, 1).data(), k, p);
  Map<a_matrix> gamma(theta.block(k * p, 0, gamma_num * k, 1).data(), k, gamma_num);

  CppAD::Independent(theta);
  sigma_mat = a_matrix::Zero(k , k);
  for(i = 0; i < k; i++) {
    sigma_mat(i, i) = pow(theta[k*p + gamma_num*k + i], 2);
  }

  // for(count=0; count < cov_mat(0,0); count++) {
  //   for(i = (cov_mat(0,count*2+1)-1); i < cov_mat(0,count*2+2); i++) {
  //     for (j = i + 1; j < cov_mat(0,count*2+2); j++) {
  //       sigma_mat(i, j) = theta[k*p + 4*k + count]*theta[k*p + 3*k + i]*theta[k*p + 3*k + j];
  //       sigma_mat(j, i) = theta[k*p + 4*k + count]*theta[k*p + 3*k + i]*theta[k*p + 3*k + j];
  //     }
  //   }
  // }

  if (cov_mat(0,0)!=0) {
    for(count=0; count < cov_mat.rows(); count++) {
      for(i = 0; i < cov_mat(count,1); i++) {
        sigma_mat(cov_mat(count,i*2+2), cov_mat(count,i*2+3)) = theta[k*p + (gamma_num+1)*k + count]*theta[k*p + gamma_num*k + cov_mat(count,i*2+2)]*theta[k*p + gamma_num*k + cov_mat(count,i*2+3)];
        sigma_mat(cov_mat(count,i*2+3), cov_mat(count,i*2+2)) = theta[k*p + (gamma_num+1)*k + count]*theta[k*p + gamma_num*k + cov_mat(count,i*2+2)]*theta[k*p + gamma_num*k + cov_mat(count,i*2+3)];
      }
    }
  }





  for(i = 0; i < k; i++){
    if (fun_type==0){
      y[i] = y[i] - gamma(i, 0)/(1 + exp(-(10/(1+exp(-gamma(i, 1))))*(alphaz[0] - gamma(i, 2))));
    } else if (fun_type==1) {
      y[i] = y[i] - gamma(i, 0)/pow((1 + exp(-(10/(1+exp(-gamma(i, 1))))*(alphaz[0] - gamma(i, 2)))/gamma(i, 3)), gamma(i, 3)); 
    } else if (fun_type==2) {
      if (alphaz[0] < gamma(i, 2)){
        y[i] = y[i] - 2*gamma(i, 3)/(1 + exp(-(10/(1+exp(-gamma(i, 1))))*(alphaz[0] - gamma(i, 2)))); //K:add
      } else {
        y[i] = y[i] - 2*gamma(i, 3) + gamma(i, 0) -2*(gamma(i, 0)-gamma(i,3))/(1 + exp(- gamma(i, 3) * (10/(1+exp(-gamma(i, 1))))*(alphaz[0] - gamma(i, 2))/(gamma(i,0)-gamma(i,3)))); //K:add
      }
    } else if (fun_type==3) {
      y[i] = y[i] - gamma(i, 0)/pow((1 + exp(-(10/(1+exp(-gamma(i, 1))))*(alphaz[0] - gamma(i, 2)))/(10/(1+exp(-gamma(i, 3))))), (10/(1+exp(-gamma(i, 3))))); 
    } else if (fun_type==4) {
      if (alphaz[0] < gamma(i, 2)){
        y[i] = y[i] - 2*(gamma(i, 0)/(1+exp(-gamma(i, 3))))/(1 + exp(-(10/(1+exp(-gamma(i, 1))))*(alphaz[0] - gamma(i, 2)))); //K:add
      } else {
        y[i] = y[i] - 2*(gamma(i, 0)/(1+exp(-gamma(i, 3)))) + gamma(i, 0) -2*(gamma(i, 0)-(gamma(i, 0)/(1+exp(-gamma(i, 3)))))/(1 + exp(- (gamma(i, 0)/(1+exp(-gamma(i, 3)))) * (10/(1+exp(-gamma(i, 1))))*(alphaz[0] - gamma(i, 2))/(gamma(i,0)-(gamma(i, 0)/(1+exp(-gamma(i, 3))))))); //K:add
      }
    } else if (fun_type==5) {
      if (alphaz[0] < gamma(i, 2)){
        y[i] = y[i] - 2*(0.1*gamma(i, 0)+0.8*gamma(i, 0)/(1+exp(-gamma(i, 3))))/(1 + exp(-(10/(1+exp(-gamma(i, 1))))*(alphaz[0] - gamma(i, 2)))); //K:add
      } else {
        y[i] = y[i] - 2*(0.1*gamma(i, 0)+0.8*gamma(i, 0)/(1+exp(-gamma(i, 3)))) + gamma(i, 0) -2*(gamma(i, 0)-(0.1*gamma(i, 0)+0.8*gamma(i, 0)/(1+exp(-gamma(i, 3)))))/(1 + exp(- (0.1*gamma(i, 0)+0.8*gamma(i, 0)/(1+exp(-gamma(i, 3)))) * (10/(1+exp(-gamma(i, 1))))*(alphaz[0] - gamma(i, 2))/(gamma(i,0)-(0.1*gamma(i, 0)+0.8*gamma(i, 0)/(1+exp(-gamma(i, 3))))))); //K:add
      }
    } else {
      
    }
  }
  y -= beta * x;


  // compute gradient/hessian of log likelihood
  likelihood[0] =-0.5*log(sigma_mat.determinant())+(-0.5*y.transpose()*sigma_mat.inverse()*y)(0);



  CppAD::ADFun<double> f(theta, likelihood);
  std::vector<double> jac = f.Jacobian(theta0);
  std::vector<double> hes = f.Hessian(theta0, 0);
  List L = List::create(jac,hes);
  return L;
}

// [[Rcpp::export]]
List louis_gau(NumericVector theta0, NumericMatrix x0, NumericMatrix y0,
               NumericMatrix z0, NumericVector alpha0, NumericMatrix err0,
               NumericMatrix weight0, Eigen::MatrixXi ind, Eigen::MatrixXi gp_ind, size_t num, size_t nd, size_t gamma_num, size_t fun_type) {
  size_t k = y0.ncol(), p = x0.ncol(), nr = err0.nrow(), i,j, num_all = y0.nrow(), q=z0.ncol(), kk, k3, tm, e,f,g,count = 0;
  int K = k, P=p, Q=q, gp=gp_ind.rows();
  MatrixXd oct, mat_det, temp2, temp1, temp, results, mat_freq, theta_mat,theta_grad_temp,theta_grad,theta_hess_temp,theta_hess;
  // temp1 = Eigen::MatrixXd::Zero(pow(P + 4, 2) + P +4, K);
  temp2 = Eigen::MatrixXd::Zero(pow(Q, 2) + Q, 1);
  theta_grad = Eigen::MatrixXd::Zero(K*(P+gamma_num+1) + gp,1);
  theta_hess = Eigen::MatrixXd::Zero(K*(P+gamma_num+1) + gp, K*(P+gamma_num+1) + gp);
  std::vector<double> out2, out1;
  // Parameter Initialization
  Map<Eigen::VectorXd> theta(Rcpp::as<Eigen::Map<Eigen::VectorXd> >(theta0));
  Map<Eigen::MatrixXd> beta(theta.block(0, 0, k * p, 1).data(), k, p);
  Map<Eigen::MatrixXd> gamma(theta.block(k*p, 0, gamma_num * k, 1).data(), k, gamma_num);
  Map<Eigen::VectorXd> alpha(Rcpp::as<Eigen::Map<Eigen::VectorXd> >(alpha0));
  Map<Eigen::MatrixXd> err(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(err0));
  Map<Eigen::MatrixXd> weights(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(weight0));
  Map<Eigen::MatrixXd> x(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(x0));
  Map<Eigen::MatrixXd> z(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(z0));
  Map<Eigen::MatrixXd> y(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(y0));
  Map<Eigen::MatrixXd> theta_tempt(theta.data(), K, P +gamma_num+1);
  theta_mat = theta_tempt;
  std::vector<double> phi0 = as<std::vector<double> >(alpha0);
  std::vector<double> theta11 = as<std::vector<double> >(theta0);
  Eigen::MatrixXd sigma_mat, sigma_m;
  sigma_mat = Eigen::MatrixXd::Zero(k, k);
  for(i = 0; i < k; i++) {
    sigma_mat(i, i) = pow(theta[k*p + gamma_num*k + i], 2);
  }


  for(i = 0; i < gp; i++) {
    for (j = 0; j < gp_ind(i,0); j++) {
      sigma_mat(gp_ind(i,2*j+1),gp_ind(i,2*j+2)) = theta[k*p + gamma_num*k + k + i]*theta[k*p + gamma_num*k + gp_ind(i,2*j+1)]*theta[k*p + gamma_num*k + gp_ind(i,2*j+2)];
      sigma_mat(gp_ind(i,2*j+2),gp_ind(i,2*j+1)) = theta[k*p + gamma_num*k + k + i]*theta[k*p + gamma_num*k + gp_ind(i,2*j+1)]*theta[k*p + gamma_num*k + gp_ind(i,2*j+2)];
    }
  }

  mat_det = Eigen::MatrixXd::Ones(nr, 1);
  g = ind(num, 0);
  sigma_m = Eigen::MatrixXd::Zero(g, g);
  for(i = 0; i < g; i++) {
    e = ind(num, i+1);
    for (tm = 0; tm < g; tm++) {
      f = ind(num, tm+1);
      sigma_m(i, tm) = sigma_mat(e, f);
    }
  }
  mat_det *= (log(pow(2*M_PI, -.5*ind(0, 0))) +  -0.5*log(sigma_m.determinant()));
  oct = MH_cal(x.row(num), y.row(num), z.row(num), k, p, nr, theta, beta, gamma, alpha, err, sigma_m, ind.row(num), fun_type);
  results = mat_det + oct;
  results = results.array() - results.maxCoeff();
  results =  results.unaryExpr(&eigen_exp);
  mat_freq = results.array()*weights.array()/(results.transpose()*weights)(0);
  temp = (z.row(num)*alpha).transpose().replicate(nr,1) + err;
  out2 = phi_deriv2(phi0, z.row(num), temp, nd);
  Map<MatrixXd> m2(out2.data(), pow(Q, 2) + Q, 1);
  temp2 = m2;
  
  List C = List::create(mat_freq,temp,temp2);
  return C;
}


// [[Rcpp::export]]
Eigen::MatrixXd rejection_method(NumericMatrix x0, NumericMatrix y0, NumericVector alpha0,
                                 NumericMatrix cov_mat0, NumericMatrix beta_temp0, NumericMatrix gamma_temp0,
                                 Eigen::MatrixXi select_k) {
  int k=select_k.rows(),i,j, n=alpha0.length();
  // Parameter Initialization
  Map<Eigen::MatrixXd> beta_temp(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(beta_temp0));
  Map<Eigen::MatrixXd> gamma_temp(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(gamma_temp0));
  Map<Eigen::MatrixXd> cov_mat(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(cov_mat0));
  Map<Eigen::MatrixXd> x(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(x0));
  Map<Eigen::VectorXd> alpha(Rcpp::as<Eigen::Map<Eigen::VectorXd> >(alpha0));
  Map<Eigen::MatrixXd> y(Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(y0));

  Eigen::MatrixXd sigma_m;
  Eigen::VectorXd y_temp, temp;
  sigma_m = Eigen::MatrixXd::Zero(k, k);
  y_temp = Eigen::VectorXd::Zero(k);
  temp = Eigen::VectorXd::Zero(n);
  for(i = 0; i < k; i++) {
    for(j=0; j <k; j++) {
      sigma_m(i, j) = cov_mat(select_k(i,0)-1, select_k(j,0)-1);
    }
  }

  for(j=0; j <n; j++){
    for(i = 0; i < k; i++){
      y_temp[i] = (- beta_temp.row(select_k(i,0)-1) * x)(0);
      y_temp[i] = y_temp[i] + y(select_k(i,0)-1,0)  - gamma_temp(select_k(i,0)-1, 0)/(1 + exp(-gamma_temp(select_k(i,0)-1, 1) * (alpha[j] - gamma_temp(select_k(i,0)-1, 2))));
    }
    temp[j] = (y_temp.transpose()*sigma_m.inverse()*y_temp)(0);
    temp[j] = exp(-0.5*temp[j]);
  }

  return temp;
}

//

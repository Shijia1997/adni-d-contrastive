################################################################
# converge_k10_verify.R
# 
# Reproduces Zheyu's original k=10 (10 scalar biomarker) fit.
# Purpose: verify R machinery + data preparation 跑通, 
#          before adding image PCs.
# 
# Expected behavior: 因为 init = Zheyu's converged value, 
#                    Newton-Raphson 应该几 iter 就 converge (small movement).
################################################################

library(statmod)
library(MASS)
library(boot)
library(Rcpp)
library(Matrix)
library(mvtnorm)
library(dplyr)
library(common)
library(logr)

args <- commandArgs(trailingOnly = TRUE)
input_csv <- if (length(args) >= 1) args[1] else "wang_input_k10.csv"
output_dir <- if (length(args) >= 2) args[2] else "adni_k10_verify/"
adni_init_dir <- if (length(args) >= 3) args[3] else "ADNI_k10/"

cat("INPUT:        ", input_csv, "\n")
cat("OUTPUT:       ", output_dir, "\n")
cat("INIT DIR:     ", adni_init_dir, "\n")

path <- ""
fun_type <- 'sigmoid'
dataset <- 'adni'
opt <- 'NR_i'

Rcpp::sourceCpp(paste(path, "test0822.cpp", sep=''))
source(paste(path, "ADLDA_funs.R", sep=''))
source(paste(path, "newton_iter.R", sep=''))

dir.create(paste(path, output_dir, sep=''), showWarnings = FALSE)
dir.create(paste(path, output_dir, "err", sep=''), showWarnings = FALSE)
dir.create(paste(path, output_dir, "result", sep=''), showWarnings = FALSE)
dir.create(paste(path, output_dir, "log", sep=''), showWarnings = FALSE)

gq_nodes <- 100
p_weight <- 10^0.3
maxit <- 100  # Should converge fast since init is already converged
gamma_num <- 3
stop_criterion <- function(gnorm, conv_criterion) {
  return ((conv_criterion < 10^-3) & (gnorm < 10^-3))
}

dat <- read.csv(paste(path, input_csv, sep=''))
cat("Data shape:", nrow(dat), "x", ncol(dat), "\n")

k <- 10
p <- 5
q <- 2

y <- as.matrix(dat[, c(1:k)])
x <- cbind(1, as.matrix(dat[, (k+1):(k+p-1)]))
z <- as.matrix(dat[, (k+1):(k+q)])

theta0 <- as.matrix(read.csv(paste0(adni_init_dir, "theta.csv")))
phi0 <- as.numeric(as.matrix(read.csv(paste0(adni_init_dir, "phi.csv"), header=F)))
cor0 <- as.numeric(as.matrix(read.csv(paste0(adni_init_dir, "cor.csv"), header=F)))

stopifnot(nrow(theta0) == 10)

cov_str <- matrix(c(3,0,1,0,2,1,2,
                    3,3,4,3,5,3,6,
                    1,4,5,NA,NA,NA,NA,
                    2,4,6,5,6,NA,NA,
                    1,7,8,NA,NA,NA,NA,
                    2,7,9,8,9,NA,NA),
                  nrow = 6, byrow = T)
cov_str[, -1] <- cov_str[, -1] + 1

theta0_fixed <- matrix(data = 0, nrow = k, ncol = p + gamma_num + 1)
theta0_fixed[, c(p + 1)] <- 1
cor0_fixed <- rep(1, 6)

lp = 'adni_k10_verify'

nlme_gqnr(x = x, y = y, z = z,
          phi0 = phi0, theta0 = theta0, cor0 = cor0,
          cov_str = cov_str,
          gq_nodes = gq_nodes, p_weight = p_weight,
          theta0_fixed = theta0_fixed, cor0_fixed = cor0_fixed,
          maxit = maxit, fun_type = fun_type,
          path = path, output_path = output_dir,
          lp = lp, opt = opt)

cat("\n=== Verify fit complete ===\n")

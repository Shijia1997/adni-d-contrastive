################################################################
# converge_k20.R
# Modified from Zheyu's converge.R to add 10 image PCs as extra biomarkers.
#
# CHANGES vs original converge.R:
#   1. k = 20 (was 10)
#   2. Read extended theta.csv (20 rows)
#   3. cov_str: unchanged (image PCs assumed independent, no new pairs)
#   4. Data: cols 1-20 are biomarker (10 scalar + 10 image PC z-scored)
#            cols 21-24 covariates (age, apoe, sex, edu)
#   5. Output path: adni_k20/
#   6. ID column: RID (renamed from Study.ID expectation)
################################################################

library(statmod)
library(MASS)
library(boot)
library(Rcpp)
library(Matrix)
library(mvtnorm)
library(dplyr)
library(common)
library(logr)

# Command-line args
args <- commandArgs(trailingOnly = TRUE)
input_csv <- if (length(args) >= 1) args[1] else "wang_input_k20.csv"
output_dir <- if (length(args) >= 2) args[2] else "adni_k20/"
adni_init_dir <- if (length(args) >= 3) args[3] else "ADNI/"
k <- if (length(args) >= 4) as.integer(args[4]) else 20
p_weight <- if (length(args) >= 5) as.numeric(args[5]) else 10^0.3

cat("INPUT CSV:        ", input_csv, "\n")
cat("OUTPUT DIR:       ", output_dir, "\n")
cat("ADNI INIT DIR:    ", adni_init_dir, "\n")
cat("K BIOMARKERS:     ", k, "\n")
cat("P WEIGHT:         ", p_weight, "\n")

##### Global Settings
path <- ""
fun_type <- 'sigmoid'
dataset <- 'adni'
opt <- 'NR_i'

# Source machinery (assumes these are in working dir)
Rcpp::sourceCpp(paste(path, "test0822.cpp", sep=''))
source(paste(path, "ADLDA_funs.R", sep=''))
source(paste(path, "newton_iter.R", sep=''))

dir.create(paste(path, output_dir, sep=''), showWarnings = FALSE)
dir.create(paste(path, output_dir, "err", sep=''), showWarnings = FALSE)
dir.create(paste(path, output_dir, "result", sep=''), showWarnings = FALSE)
dir.create(paste(path, output_dir, "log", sep=''), showWarnings = FALSE)

gq_nodes  <-  100
maxit  <- 400
stop_criterion <- function(gnorm, conv_criterion) {
  return ((conv_criterion < 10^-3) & (gnorm < 10^-3))
}

gamma_num = 3
if (fun_type == "sigmoid") { gamma_num = 3 }

#### Load data
# Format expected: cols 1-20 biomarker (10 scalar + 10 image PC), 
#                  cols 21-24 covariates (age, apoe, sex, edu),
#                  plus metadata columns (RID, EXAMDATE, etc.)
dat <- read.csv(paste(path, input_csv, sep=''))
cat("Data shape:", nrow(dat), "x", ncol(dat), "\n")
cat("First 30 column names:\n")
print(head(colnames(dat), 30))

p <- 5   # intercept + 4 covariate
q <- 2   # age, apoe for disease equation

y <- as.matrix(dat[, c(1:k)])
x <- cbind(1, as.matrix(dat[, (k+1):(k+p-1)]))  # cols 21-24 + intercept
z <- as.matrix(dat[, (k+1):(k+q)])              # cols 21-22

cat("Dimensions: k=", k, ", p=", p, ", q=", q, "\n")
cat("y shape:", dim(y), "\n")
cat("x shape:", dim(x), "\n")
cat("z shape:", dim(z), "\n")

#### Load init values
theta0 <- as.matrix(read.csv(paste0(adni_init_dir, "theta.csv")))
phi0 <- as.numeric(as.matrix(read.csv(paste0(adni_init_dir, "phi.csv"), header=F)))
cor0 <- as.numeric(as.matrix(read.csv(paste0(adni_init_dir, "cor.csv"), header=F)))

cat("theta0 shape:", dim(theta0), "(expect 20 x 9)\n")
cat("phi0 length:", length(phi0), "(expect 2)\n")
cat("cor0 length:", length(cor0), "(expect 6)\n")

stopifnot(nrow(theta0) == k)
stopifnot(ncol(theta0) == p + gamma_num + 1)
stopifnot(length(phi0) == q)

#### cov_str: only scalar correlation block (image PC assumed independent)
# Same as Zheyu's ADNI cov_str — image PCs not in any pair = independent.
cov_str <- matrix(c(3,0,1,0,2,1,2,
                    3,3,4,3,5,3,6,
                    1,4,5,NA,NA,NA,NA,
                    2,4,6,5,6,NA,NA,
                    1,7,8,NA,NA,NA,NA,
                    2,7,9,8,9,NA,NA),
                  nrow = 6, byrow = T)
cov_str[, -1] <- cov_str[, -1] + 1

# theta0_fixed: γ_1 column fixed = 1 (height not estimated, follows paper Section 3.2.2)
theta0_fixed <- matrix(data = 0, nrow = k, ncol = p + gamma_num + 1)
theta0_fixed[, c(p + 1)] <- 1  # γ_1 fixed

cor0_fixed <- rep(1, 6)  # all 6 scalar correlations are fixed-on (estimated)

# ID column for output / bootstrap
if ("Study.ID" %in% colnames(dat)) {
  IDs <- dat$Study.ID
} else if ("RID" %in% colnames(dat)) {
  IDs <- dat$RID
} else {
  stop("No RID or Study.ID column found")
}

lp = paste(dataset, '_k', k, '_converge', sep = "")

cat("\n=== Running nlme_gqnr ===\n")
cat("Output will be in:", output_dir, "\n")

nlme_gqnr(x = x, y = y, z = z,
          phi0 = phi0,
          theta0 = theta0,
          cor0 = cor0,
          cov_str = cov_str,
          gq_nodes = gq_nodes,
          p_weight = p_weight,
          theta0_fixed = theta0_fixed,
          cor0_fixed = cor0_fixed,
          maxit = maxit,
          fun_type = fun_type,
          path = path,
          output_path = output_dir,
          lp = lp,
          opt = opt)

cat("\n=== Fit complete ===\n")

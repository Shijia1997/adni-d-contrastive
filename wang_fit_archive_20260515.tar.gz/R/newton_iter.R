# functions for optimization algorithms
fun_type_num <- function(fun_type){
  if (fun_type == 'sigmoid') {
    return(0)
  } else if (fun_type == 'richards') {
    return(1) 
  } else if (fun_type == 'piecewise') {
    return(2)
  } else if (fun_type == 'richards11' | fun_type == 'richards12') {
    return(3)
  } else if (fun_type == 'piecewise11' | fun_type == 'piecewise12') {
    return(4)
  } else if (fun_type == 'piecewise21' | fun_type == 'piecewise22') {
    return(5)
  } else {
    stop('no such function type.')
  }
}

evalue_min <- function(hess){
  return(eigen(hess)$values[dim(hess)[1]])
  #A <- Variable(dim(hess)[1],dim(hess)[2])
  #prob <- Problem(Maximize(lambda_min(A)), list(A == hess))
  #result <- solve(prob)
  #return(result$value)
}


newton_iter<- function(theta0, phi0, x1, y1, z1, es, weight, ind, cov_list, 
                        cov_pos, hess_fd, nodes, w, w4,fix_pos, gamma_num, fun_type, opt='NR'){
  grad <- matrix(0,nrow = length(theta0)+q,ncol = 1) 
  hess1 <- hess2 <- hess3 <- matrix(0,nrow = length(theta0)+q,ncol = length(theta0)+q) 
  for (sub_id in 1:nrow(y1)) {
    ## remove the parameters corresponding to missing markers
    theta_m <- matrix(theta0[1:(k*(p+gamma_num+1))],nrow = k,ncol = p+gamma_num+1,byrow = F)
    id_save <- ind[sub_id,2:(ind[sub_id,1]+1)]+1
    theta_m <- as.numeric(theta_m[id_save,])
    if(length(cov_pos[[sub_id]])!=0) {
      gpidsave <- c(cov_pos[[sub_id]][,1])
      theta_m <- c(theta_m, theta0[k*(p+gamma_num+1)+ gpidsave])
    }
    id_na <- hess_fd[sub_id,!is.na(hess_fd[sub_id,])]
    
    if (length(cov_pos[[sub_id]])==0) {
      true_pos <- matrix(0)
    } else {
      true_pos <- cov_pos[[sub_id]]
    }
    
    
    sec <- matrix(0,nrow = length(theta0)+q,ncol = 1) 
    for (nd in 1:nodes) {
      qes <- matrix(0,nrow = length(theta0)+q,ncol = 1) 
      cv <- louis_gau(theta0 = theta0,x0 = x1, y0 = y1[,1:k],z0 = z1,alpha0 = phi0, err0 = es, weight0 = weight, 
                      ind =ind,gp_ind = cov_list,num = sub_id-1, nd=nd-1, gamma_num=gamma_num, fun_type=fun_type_num(fun_type)) 
      phi0_temp <- cv[[3]] 
      temp2_g <- phi0_temp[1:q] 
      temp2_h <- matrix(data = phi0_temp[(q+1):(q+q^2)],nrow = q,ncol = q) 
      d_temp <- cv[[2]] 
      wet <- cv[[1]] 
      theta_bt <- theta_deriv_temp(theta0 = theta_m, 
                                   x0 = matrix(x1[sub_id,],nrow = 1), 
                                   alphaz0 = matrix(d_temp[nd]),
                                   y0 = matrix(y1[sub_id,id_save],nrow = 1),cov_mat = true_pos, gamma_num=gamma_num, fun_type=fun_type_num(fun_type))
      #if (is.na(wet[nd])) {
      #  stop(paste('sub_id: ', sub_id, 'nd: ', nd, 'wet[nd]: ', sep='/n'))
      #}
      #if (sum(is.na(theta_bt[[1]]))!=0){
      #  stop(paste('sub_id: ', sub_id, 'nd: ', nd, 'theta_bt[[1]]: ', sep='/n'))
      #}
      #if (sum(is.na(theta_bt[[2]]))!=0){
      #  stop(paste('sub_id: ', sub_id, 'nd: ', nd, 'theta_bt[[2]]: ', sep='/n'))
      #}
      sec[id_na,] <- sec[id_na,] + theta_bt[[1]]*wet[nd] 
      sec[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),] <- sec[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),] + temp2_g*wet[nd] 
      hess1[id_na,id_na] <- hess1[id_na,id_na] + theta_bt[[2]]*wet[nd] 
      hess1[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),(1:q)+(k*(p+gamma_num+1)+nrow(cov_list))] <- hess1[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),(1:q)+(k*(p+gamma_num+1)+nrow(cov_list))] + temp2_h*wet[nd] 
      qes[id_na,] <- theta_bt[[1]] 
      qes[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list)),] <- temp2_g 
      hess2 <- hess2 + wet[nd]*(qes %*% t(qes)) 
    }
    grad <- grad + sec 
    hess3 <- hess3 + sec %*% t(sec) 
  }

  if (opt=='old'){
  hess <- hess1
  } else{
  hess <- hess1 + hess2 - hess3 
  }
  
  ## add a penalty to gamma2 and gamma4
  for (i in 1:k) {
    nk <- (sum(!is.na(y1[,i])))^0.25
    gk <- w*nk*tanh(theta0[k*(p+1)+i]/2); hk <- w*nk*(1/(1+cosh(theta0[k*(p+1)+i])))
    grad[k*(p+1)+i,1] <- grad[k*(p+1)+i,1] - gk
    hess[k*(p+1)+i,k*(p+1)+i] <- hess[k*(p+1)+i,k*(p+1)+i] - hk
    if (fun_type=='piecewise12' | fun_type=='piecewise22'){
      gk <- w4*nk*tanh(theta0[k*(p+3)+i]/2); hk <- w4*nk*(1/(1+cosh(theta0[k*(p+3)+i])))
      grad[k*(p+3)+i,1] <- grad[k*(p+3)+i,1] - gk
      hess[k*(p+3)+i,k*(p+3)+i] <- hess[k*(p+3)+i,k*(p+3)+i] - hk
    } 
  }
  
  para_temp <- c(theta0, phi0)
 if (opt=='GD_NR'){
    if (as.numeric((matrix(grad,nrow = 1)[,-fix_pos]) %*% (matrix(grad,ncol= 1)[-fix_pos,])) <= 1000){
      opt<-0
    } else {
      opt<-1
    }
  }
  
  if (opt=='NR'| opt=='old'){ # pure newton's method
    if (length(fix_pos) != 0) { 
      para_temp[-fix_pos] <- para_temp[-fix_pos] -as.numeric(matrix(grad,nrow = 1)[,-fix_pos] %*% solve(matrix(hess,nrow = length(para_temp))[-fix_pos,-fix_pos])) 
    } else { 
      para_temp <- para_temp - as.numeric(matrix(grad,nrow = 1) %*% solve(matrix(hess,nrow = length(para_temp)))) 
    } 
  } else if (opt=='GD') { 
    if (length(fix_pos) != 0) { 
      para_temp[-fix_pos] <- para_temp[-fix_pos] + 0.0001 * as.numeric(matrix(grad,nrow = 1)[,-fix_pos])
    } else { 
      para_temp <- para_temp + 0.0001 * as.numeric(matrix(grad,nrow = 1))
    } 
  } else if (opt=='GD_back') { 
    a_<-1
    c <- 0.1
    para_update <- para_temp
    rhs_ <- -nlme_loglikeli(theta0 = theta0, x0 = x, y0 = y[,1:k],z0 = z,alpha0 = phi0, err0 = es,weight0 = weight,ind = ind, gp_ind = cov_list,gamma_num=gamma_num, fun_type=fun_type_num(fun_type))
    a_<-1
    repeat{
      if (length(fix_pos) != 0) { 
        para_update[-fix_pos] <- para_temp[-fix_pos] + a_ * as.numeric(matrix(grad,nrow = 1)[,-fix_pos]) 
        lhs<- - nlme_loglikeli(theta0 = para_update[1:(k*(p+gamma_num+1)+nrow(cov_list))] , x0 = x, y0 = y[,1:k],z0 = z,alpha0 = para_update[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list))], err0 = es,weight0 = weight,ind = ind, gp_ind = cov_list,gamma_num=gamma_num, fun_type=fun_type_num(fun_type)) 
        rhs <- rhs_ - c*a_*as.numeric(matrix(grad,nrow = 1)[,-fix_pos] %*% matrix(grad,ncol = 1)[-fix_pos,]) 
      } else {
        para_update <- para_temp + a_ * as.numeric(matrix(grad,nrow = 1)) 
        lhs<- - nlme_loglikeli(theta0 = para_update[1:(k*(p+gamma_num+1)+nrow(cov_list))] , x0 = x, y0 = y[,1:k],z0 = z,alpha0 = para_update[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list))], err0 = es,weight0 = weight,ind = ind, gp_ind = cov_list,gamma_num=gamma_num, fun_type=fun_type_num(fun_type)) 
        rhs <- rhs_ - c*a_*as.numeric(matrix(grad,nrow = 1) %*% matrix(grad,ncol = 1)) 
      }
      if ((!is.na(lhs)) & (!is.infinite(lhs))){
        if (lhs <= rhs){
        ak_ <- a_
        if (length(fix_pos) != 0) { 
          para_temp[-fix_pos] <- para_temp[-fix_pos] + ak_ * as.numeric(matrix(grad,nrow = 1)[,-fix_pos])
        } else { 
          para_temp <- para_temp + ak_ * as.numeric(matrix(grad,nrow = 1))
        } 
        break
        }
      }
      a_<-0.9 * a_
    }
  } else if (opt=='NR_i') {
    lambda_ <- max(1-evalue_min(-hess),0)
    if (length(fix_pos) != 0) { 
      para_temp[-fix_pos] <- para_temp[-fix_pos] - as.numeric(matrix(grad,nrow = 1)[,-fix_pos] %*% solve(matrix(hess-lambda_*diag(length(para_temp)),nrow = length(para_temp))[-fix_pos,-fix_pos])) 
    } else { 
      para_temp <- para_temp - as.numeric(matrix(grad,nrow = 1) %*% solve(matrix(hess-lambda_*diag(length(para_temp)),nrow = length(para_temp)))) 
    } 
  } else if (opt=='NR_cholesky') {
    if (length(fix_pos) != 0) { 
      hess <- chol(-hess, mod=True, p=1)
      print(evalue_min(hess))
      para_temp[-fix_pos] <- para_temp[-fix_pos] - as.numeric(matrix(grad,nrow = 1)[,-fix_pos] %*% solve(matrix(-hess,nrow = length(para_temp))[-fix_pos,-fix_pos])) 
    } else { 
      hess <- chol(hess, mod=True, p=1)
      para_temp <- para_temp - as.numeric(matrix(grad,nrow = 1) %*% solve(matrix(hess,nrow = length(para_temp)))) 
    } 
  } else {
    
  }
  
  theta0 <- para_temp[1:(k*(p+gamma_num+1)+nrow(cov_list))] 
  phi0 <- para_temp[(1:q)+(k*(p+gamma_num+1)+nrow(cov_list))] 
  para_new <- list()
  para_new[[1]] <- theta0
  para_new[[2]] <- phi0
  para_new[[3]] <- -nlme_loglikeli(theta0 = theta0, x0 = x, y0 = y[,1:k],z0 = z,alpha0 = phi0, err0 = es,weight0 = weight,ind = ind, gp_ind = cov_list,gamma_num=gamma_num, fun_type=fun_type_num(fun_type))
  para_new[[4]] <- as.numeric((matrix(grad,nrow = 1)[,-fix_pos]) %*% (matrix(grad,ncol= 1)[-fix_pos,]))
  #log_print(hess)
  para_new[[5]] <- evalue_min(hess)
  para_new[[6]] <-  grad[-fix_pos]
  return(para_new)
}

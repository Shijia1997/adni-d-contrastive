#!/bin/bash
#SBATCH -J wang_k30_main
#SBATCH -p shared
#SBATCH -t 36:00:00
#SBATCH -c 12
#SBATCH --mem=64G
#SBATCH -o logs/step30_%j.out
#SBATCH -e logs/step30_%j.err

set -eo pipefail

cd "$SLURM_SUBMIT_DIR"
mkdir -p logs

module load R/4.3
export R_LIBS_USER=/dcs07/zwang/data/adni_d/wang_fit/R_libs
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export OPENBLAS_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export MKL_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export VECLIB_MAXIMUM_THREADS="${SLURM_CPUS_PER_TASK}"
export NUMEXPR_NUM_THREADS="${SLURM_CPUS_PER_TASK}"

echo "=== Step 30: k=30 main fit (10 scalar + 20 image PC) ==="
echo "Started: $(date)"
echo "Working dir: $(pwd)"
echo "Rscript: $(which Rscript)"
echo "R_LIBS_USER: ${R_LIBS_USER}"
echo "Threads: ${SLURM_CPUS_PER_TASK}"
echo ""

Rscript R/converge_k20.R \
  wang_input_k30.csv \
  adni_k30_main/ \
  ADNI_k30/ \
  30

echo ""
echo "Done: $(date)"

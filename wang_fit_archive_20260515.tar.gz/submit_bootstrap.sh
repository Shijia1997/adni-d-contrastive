#!/bin/bash
#SBATCH -J wang_bootstrap
#SBATCH -p shared
#SBATCH -t 08:00:00
#SBATCH -c 1
#SBATCH --mem=16G
#SBATCH -o logs/bs_%A_%a.out
#SBATCH -e logs/bs_%A_%a.err

set -eo pipefail

cd "$SLURM_SUBMIT_DIR"
mkdir -p logs bootstrap_output

module load R/4.3
export R_LIBS_USER=/dcs07/zwang/data/adni_d/wang_fit/R_libs

python scripts/run_bootstrap.py \
  --iter "$SLURM_ARRAY_TASK_ID" \
  --seed "$SLURM_ARRAY_TASK_ID" \
  --base_input wang_input_k20.csv \
  --r_script R/converge_k20.R \
  --init_dir ADNI \
  --working_dir . \
  --output_root bootstrap_output

# Wang Fit Image Feature Attempt Archive

Date: 2026-05-15

This directory archives the first attempt to add Swin sMRI image features to Wang/Zheyu's joint disease progression model.

## Current Decision

Do not use the partial `k=10` fit from this workspace as a disease-stage target.

Use the existing `d_mod3` column in `D_with_image_paths.csv` as the supervisor for the next direction. That column is Zheyu's already-estimated disease quantity and is complete for all 12,934 visits.

## Key Findings

- `k=10` scalar-only verify job ran to iteration 34, then crashed with a C++ segmentation fault inside `theta_deriv_temp()`.
- The `k=10` fit did not converge and did not write a final `.RData`.
- `k=20`, `k=30`, and conservative `k=15` image-feature Wang fits were numerically unstable.
- The image-feature fits repeatedly produced `neg_likelihood = Inf`, consistent with weak/non-monotonic image PC signal under the sigmoid biomarker assumption.

## Last Visible k=10 State

The `k=10` scalar run was numerically reasonable before the segfault, but not converged:

- Iteration: 34
- Loss: 82193.82
- Negative likelihood: 79744.79
- Convergence criterion: 0.07325702
- Required convergence criterion was approximately `< 0.001`

Last visible `gamma3` values:

```text
2.2136, 2.0586, 2.3158, 1.7576, 1.8430,
1.7535, 1.8216, 0.9172, 0.8470, 0.1467
```

These show a plausible event ordering but should not be used as final paper values.

## d_mod3 Validation

`D_with_image_paths.csv` was checked directly:

- Rows: 12,934
- `d_mod3` non-missing: 12,934 (100%)
- Range: `[-3.569, 3.665]`
- `d_mod2`/`d_mod3` correlation: 0.5436
- Mean `d_mod3` by diagnosis:
  - NORMAL: -0.563
  - MCI: +0.143
  - AD: +1.279
- Within-subject monotonicity allowing `-0.15` noise:
  - 1,702 / 1,836 subjects with at least 3 visits were monotonic (92.7%)

Conclusion: `d_mod3` is reliable enough to use as the disease-stage supervisor in the next direction.

## Image Embeddings to Preserve

Keep these outside git:

- `/dcs07/zwang/data/adni_d/data/embeddings/`
- `/dcs07/zwang/data/adni_d/data/embeddings_128/`
- `/dcs07/zwang/data/adni_d/data/master_smri/`

Important 128-cube files:

- `data/embeddings_128/swin_latent.npy`
- `data/embeddings_128/image_id_order.npy`
- `data/embeddings_128/swin_combat_train.npy`
- `data/embeddings_128/swin_combat_test.npy`
- `data/embeddings_128/swin_combat_pca_z_train.npy`
- `data/embeddings_128/swin_combat_pca_z_test.npy`
- `data/embeddings_128/swin_combat_pca_z_train_ids.npy`
- `data/embeddings_128/swin_combat_pca_z_test_ids.npy`

## Archived Runtime Outputs

Generated CSVs and failed run logs were moved out of the code root:

```text
archive_runs/2026-05-15_wang_fit_attempt/
```

This path is intentionally ignored by git. It is kept locally for forensic reference.

## Next Direction

Treat imaging as a supervised/individual-estimation feature problem using Zheyu's existing `d_mod3`, not as a direct additional sigmoid biomarker inside the current Wang model.


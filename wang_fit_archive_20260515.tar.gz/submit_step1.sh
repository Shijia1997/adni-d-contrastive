#!/bin/bash
#SBATCH -J wang_k10_verify
#SBATCH -p shared
#SBATCH -t 12:00:00
#SBATCH -c 12
#SBATCH --mem=48G
#SBATCH -o logs/step1_%j.out
#SBATCH -e logs/step1_%j.err

set -eo pipefail

cd "$SLURM_SUBMIT_DIR"
mkdir -p logs

module load R/4.3
export R_LIBS_USER=/dcs07/zwang/data/adni_d/wang_fit/R_libs
export OMP_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export OPENBLAS_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export MKL_NUM_THREADS="${SLURM_CPUS_PER_TASK}"
export VECLIB_MAXIMUM_THREADS="${SLURM_CPUS_PER_TASK}"
export NUMEXPR_NUM_THREADS="${SLURM_CPUS_PER_TASK}"

echo "=== Step 1: k=10 verify fit ==="
echo "Started: $(date)"
echo "Working dir: $(pwd)"
echo "Rscript: $(which Rscript)"
echo "R_LIBS_USER: ${R_LIBS_USER}"
echo "Threads: ${SLURM_CPUS_PER_TASK}"
echo ""

Rscript R/converge_k10_verify.R \
  wang_input_k10.csv \
  adni_k10_verify_12h/ \
  ADNI_k10/

echo ""
echo "Done: $(date)"
